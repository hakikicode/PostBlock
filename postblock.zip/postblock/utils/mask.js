export const mask = (address) => {
    return `${address.slice(0, 6)}...${address.slice(-3)}`;
}