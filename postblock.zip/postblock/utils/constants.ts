export const ipfsGateway = 'https://cloudflare-ipfs.com/ipfs'
export const edgeStoreGateway = 'https://data.thetaedgestore.com/api/v2/data'
export const nullAddress = '0x0000000000000000000000000000000000000000'
export const testnetExplorer = 'https://testnet-explorer.thetatoken.org'
export const mainnetExplorer = 'https://explorer.thetatoken.org'
export const explorer = testnetExplorer
export const EMPTYOFFCHAINDATA = {
    content: {
        title: '',
        body: '',
        image: ''
    },
    metadata: {
        tags: [],
        theme: '',
        creation: '',
        author: '',
    }
}

export const EMPTYONCHAINDATA = {
    author: '',
    cid: '',
    remainingTips: null,
    totalLikes: null,
    totalTips: null,
}

export const EMPTYUSER = {
    addr: "",
    description: "",
    image: "",
    name: "",
    social: ""
}