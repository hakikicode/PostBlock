export class PostBlockService {
    static async getUserByAddress(contract, [address]) {
        if (!address) return null;

        if (!await PostBlockService.isRegisteredUser(contract, [address])) return null;

        let user = null;
        try {
            user = await contract.call("getUserByAddress", [address]);
        } catch (error) {}

        return user;
    }

    static async isRegisteredUser(contract, [address]) {
        if (!address) return false;

        const userID = await contract.call("users", [address]);
        if (userID.toNumber() === 0) return false;

        return true;
    }

}