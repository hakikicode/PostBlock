export const formatTimestamp = (timestamp) => {
    const d = new Date(timestamp * 1000);
    // const month = '' + (d.getMonth() + 1);
    const day = '' + d.getDate();
    const year = d.getFullYear();
    const month = d.toLocaleString('default', { month: 'long' });
    const ordinal = nth(day);

    return `${month} ${day}${ordinal}, ${year}`;
};

export const formatDateTime = (date) => {
    var datetime = date.getDate() + " / "
        + (date.getMonth() + 1) + "/"
        + date.getFullYear() + " "
        + date.getHours() + ":"
        + date.getMinutes() + ":"
        + date.getSeconds();

    return datetime;

}

const nth = function (d) {
    if (d > 3 && d < 21) return 'th';
    switch (d % 10) {
        case 1: return "st";
        case 2: return "nd";
        case 3: return "rd";
        default: return "th";
    }
}