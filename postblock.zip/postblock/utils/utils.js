import { edgeStoreGateway } from "./constants";
import { validPost } from "./validPost";

export const isValidTxHash = (addr) => { 
    return /^0x[A-Fa-f0-9]{64}$/.test(addr);
}

export const getImageFromData = (data) => {
    if (!data || !data.content || !data.content.image) return "";
    if (!isValidTxHash(data.content.image)) return "";
    return `${edgeStoreGateway}/${data.content.image}`;
}

export const mask = (address) => {
    return `${address.slice(0, 6)}...${address.slice(-3)}`;
}

export const getOffchainData = async (cid) => {
    const response = await fetch(`${edgeStoreGateway}/${cid}`, {
        method: "GET", credentials: "same-origin", 
        headers: { "Content-Type": "application/json" },
    });
    if (!response.ok) return null; 

    const offChainData = await response.json();
    if (!validPost(offChainData)) return null;

    return offChainData;
}