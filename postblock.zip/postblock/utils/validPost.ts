const validPost = async (data) => {
    return validContent(data) && validMetadata(data);
}

let validContent = (data) => {
    if(!data.hasOwnProperty('content')) return false;

    const content = data.content;
    if(!content.hasOwnProperty('title')) return false;
    if(!content.hasOwnProperty('body')) return false;
    if(!content.hasOwnProperty('image')) return false;

    return true;
}

let validMetadata = (data) => {
    if(!data.hasOwnProperty('metadata')) return false;
    
    const metadata = data.metadata;
    if(!metadata.hasOwnProperty('author')) return false;

    return true;
}

export { validPost };
