import { BigNumber, ethers } from "ethers";

class WebThree {
    mask(address) {
        return `${address.slice(0, 6)}...${address.slice(-3)}`;
    }
}

export const web3 = new WebThree();