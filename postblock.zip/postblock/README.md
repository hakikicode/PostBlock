Timeline
- 01/04/23 Project Start, PostBlock smart contract created
- 04/04/23 Frontend
- 08/04/23 PBC20 smart contract and frontend UI implemented
- 10/04/23 Project finalised drafted
- 12/04/23 Bug fixes and UI fixes