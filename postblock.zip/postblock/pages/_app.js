import { ChakraProvider, Container } from '@chakra-ui/react'
import 'react-quill/dist/quill.snow.css'
import { ThirdwebProvider, ChainId } from "@thirdweb-dev/react";
import { Theta, ThetaTestnet } from "@thirdweb-dev/chains";
import theme from '../utils/theme'
import Navbar from '../components/Navbar/Navbar';

import {
  ThirdwebStorage,
  StorageDownloader,
  IpfsUploader,
} from "@thirdweb-dev/storage";

// Configure a custom ThirdwebStorage instance
const gatewayUrls = {
  "ipfs://": [
    "https://gateway.ipfscdn.io/ipfs/",
    "https://cloudflare-ipfs.com/ipfs/",
    "https://ipfs.io/ipfs/",
  ],
};
const downloader = new StorageDownloader();
const uploader = new IpfsUploader();
const storage = new ThirdwebStorage({ uploader, downloader, gatewayUrls });

function App({ Component, pageProps }) {
  return (
    <ThirdwebProvider
      activeChain={ThetaTestnet}
      supportedChains={[Theta, ThetaTestnet]}
      storageInterface={storage}
      >
      <ChakraProvider theme={theme}>
        <Navbar />
        <Component {...pageProps} />
      </ChakraProvider>
    </ThirdwebProvider>
  )
}

export default App