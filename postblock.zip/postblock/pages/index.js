import Header from '../components/Index/Header';
import SamplePost from '../components/Index/SamplePost';
import Statistic from '../components/Index/Statistic';
import Feature from '../components/Index/Feature';

export default function IndexPage() {
  return (
    <div>
      <Header />
      <SamplePost />
      <Statistic />
      <Feature />
    </div>
  );
}
