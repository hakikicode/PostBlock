import {
  Box,
  Grid,
  GridItem,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  SimpleGrid,
  Center
} from '@chakra-ui/react'
import { useSDK } from '@thirdweb-dev/react';
import { useEffect, useState } from 'react';
import { ethers } from "ethers";
import Post from '../../components/Post';
import NFTCollection from '../../components/NFT/NFTCollection';
import Profile from '../../components/Profile';
import { abi } from "../../utils/PostBlock/abi";
import { contractAddress } from "../../utils/PostBlock/contract";

const StaticPropsDetail = ({ props }) => {
  const sdk = useSDK();
  const [posts, setPosts] = useState([]);
  const [cids, setCids] = useState([]);

  const [postCount, setPostCount] = useState(0);

  const load = async () => {
    const contract = await sdk.getContractFromAbi(contractAddress, abi);
    let posts = await contract.call('getPost', [props.address]);
    // console.log(posts);

    let cids = [];
    posts.map(async (item, index) => {
      cids.push(item.cid);
    });
    setCids(cids);

    let nPosts = await contract.call('getUserPosts', [props.address]);
    setPostCount(nPosts);
  }

  const [isAddressValid, setIsAddressValid] = useState(false);

  useEffect(() => {
    (async () => {
      const isValid = ethers.utils.isAddress(props.address);
      setIsAddressValid(isValid);
      if (!isValid) return;

      await load();
    })();
  }, []);

  return (
    <>
      {isAddressValid
        ? <Grid templateColumns={{ md: "repeat(8, 1fr)", lg: "repeat(12, 1fr)" }} py={6}>
          <GridItem colSpan={{ md: 4, lg: 8 }}>
            <Tabs variant='soft-rounded' colorScheme='green'>
              <TabList px={6}>
                <Tab>Posts</Tab>
                <Tab>NFT Collection</Tab>
              </TabList>
              <TabPanels>
                <TabPanel>
                  <SimpleGrid minChildWidth='445px' spacing='40px'>
                    {cids.map((cid, index) => {
                      return (
                        <Box key={index}>
                          <Post cid={cid} />
                        </Box>
                      );
                    })}
                  </SimpleGrid>
                </TabPanel>
                <TabPanel>
                  <NFTCollection address={props.address} />
                </TabPanel>
              </TabPanels>
            </Tabs>
          </GridItem>
          <GridItem colSpan={4}>
            <Box pos="relative" boxSize="full" position="static">
              <Box position={"fixed"}>
                <Center>
                  <Profile address={props.address} />
                </Center>
              </Box>
            </Box>
          </GridItem>
        </Grid>
        : <></>}
    </>
  );
}

export default StaticPropsDetail

export async function getServerSideProps({ params }) {
  const props = {
    address: params.id
  }

  return {
    props: {
      props
    },
  };
}

