import { GetStaticProps } from "next"
import Link from "next/link"

const WithStaticProps = ({ items }) => (
  <>
    /users/posts
  </>
)

export const getStaticProps = async () => {
  // Example for including static props in a Next.js function component page.
  // Don"t forge`t to include the respective types for any props passed into
  // the component.
  const items = true;
  return { props: { items } }
}

export default WithStaticProps
