import {
  Button,
  Box,
  Heading,
  Grid,
  GridItem,
  Tag,
  TagLabel,
  HStack,
  Flex,
  Spacer,
  Link,
  Center,
  Tooltip,
  Circle,
  Image,
  TagLeftIcon,
  useToast,
  useColorModeValue,
} from "@chakra-ui/react"
import { mask } from "../../utils/mask";
import { formatTimestamp } from "../../utils/datepipe";
import { useEffect, useState } from "react";
import { useSDK, useAddress } from "@thirdweb-dev/react";
import { abi } from "../../utils/PostBlock/abi";
import { contractAddress } from "../../utils/PostBlock/contract";
import { StarIcon } from "@chakra-ui/icons";
import Tip from "../../components/Tip";
import Info from "../../components/Info";
import { edgeStoreGateway } from "../../utils/constants";
import { getImageFromData, getOffchainData } from "../../utils/utils";
import { validPost } from "../../utils/validPost";
import { useRouter } from "next/router";
import NFTCollect from "../../components/NFT/NFTCollect";
import { ethers } from "ethers";
import { PostBlockService } from "../../utils/services/PostBlockService";
import NFTOwnerList from "../../components/NFT/NFTOwnerList";

const StaticPropsDetail = ({ props }) => {
  const sdk = useSDK();
  const toast = useToast();
  const address = useAddress();
  const router = useRouter();
  const backgroundColor = useColorModeValue("white", "gray.900");

  const [offChainData, setOffChainData] = useState(null);
  const [onChainData, setOnChainData] = useState(null);
  const [liked, setLiked] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      if (!props.cid) { return; }
      const contract = await sdk.getContractFromAbi(contractAddress, abi);
      const onChainData = await contract.call("posts", [props.cid]);
      setOnChainData(onChainData);

      const uri = `${edgeStoreGateway}/${props.cid}`;
      const response = await fetch(uri, {
        method: "GET",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
      });
      const offChainData = await response.json();
      if (!response.ok) { return; }
      if (!validPost(offChainData)) { return; }
      setOffChainData(offChainData);

      const authorAddress = (onChainData && onChainData.author) ? onChainData.author : null;
      const user = await PostBlockService.getUserByAddress(contract, [authorAddress]);
      if (!user) { return; }
      setUser(user);

      let addressToUse = address;
      if (window && window.ethereum) {
        // For some reason address is null so resort to this (hacky)
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        const account = accounts[0];
        addressToUse = account;

        window.ethereum.on("accountsChanged", async (accounts) => {
          console.log(accounts);
          await updateLikeStatus(accounts);
        })
      }

      await updateLikeStatus(addressToUse);
    })();
  }, []);

  const like = async () => {
    const contract = await sdk.getContractFromAbi(contractAddress, abi);

    if (!await PostBlockService.isRegisteredUser(contract, [address])) return;

    let toastTitle = "Liked!";
    let toastStatus = "success";
    try {
      const tx = await contract.call("like", [props.cid]);
      const receipt = tx.receipt;

    } catch (error) {
      toastTitle = "Error while liking";
      toastStatus = "error";
    }
    finally {
      await updateLikeStatus();
      toast({ title: toastTitle, status: toastStatus, position: "bottom-right", isClosable: true });
    }
  }

  const unlike = async () => {
    const contract = await sdk.getContractFromAbi(contractAddress, abi);

    if (!address) return;
    const userID = await contract.call("users", [address]);
    if (userID.toNumber() === 0) return;

    try {
      const tx = await contract.call("unlike", [props.cid]);
      const receipt = tx.receipt;
    } catch (error) {

    }

    await updateLikeStatus();
  }

  const updateLikeStatus = async (address = null) => {
    const contract = await sdk.getContractFromAbi(contractAddress, abi);

    if (!await PostBlockService.isRegisteredUser(contract, [address])) return;

    const isLiked = await contract.call("didUserLikeThisPost", [props.cid]);
    console.log(address, props.cid, isLiked);
    setLiked(isLiked);
  }

  return (<>{(onChainData && offChainData)
    ? <Grid templateColumns="repeat(12, 1fr)" gap={6}>
      <GridItem colSpan={{ sm: 1, md: 1, lg: 3 }} />
      <GridItem colSpan={{ sm: 10, md: 10, lg: 6 }}>
        <Center border="1px solid" borderColor="gray.200"
          // boxSize="sm"
          bgImage={getImageFromData(offChainData)}
          bgPosition="center"
          bgRepeat="no-repeat"
          bgSize="cover"
          my={5} borderRadius={10} w={"100%"} h={"50vh"}>
        </Center>

        <Heading as="h1" fontWeight={700}>{offChainData.content.title || "Error while loading title"}</Heading>

        <Grid templateColumns="repeat(12, 1fr)" gap={6}>
          <GridItem colSpan={{ sm: 12, md: 12, lg: 9 }}>
            <Box py={3}>
              <HStack spacing={4}>
                <Tooltip label={mask(onChainData.author)}>
                  <Tag size="lg" variant="subtle" borderRadius="full" as={Link}
                    onClick={() => router.push(`/users/${onChainData.author}`)}
                  >
                    <Box ml={-1} mr={2} borderRadius="full">
                      <Circle bg="gray.200" mr={2} cursor="pointer"
                        onClick={() => router.push(`/users/${onChainData.author}`)}
                      >
                        <Image boxSize="24px" objectFit="cover"
                          src={`https://robohash.org/${onChainData.author}?set=set4`} alt=""
                        />
                      </Circle>
                    </Box>
                    <TagLabel>{(user && user.name) ? user.name : mask(onChainData.author)}</TagLabel>
                  </Tag>
                </Tooltip>
                <Tag size="lg" variant="subtle" borderRadius="full">
                  {formatTimestamp(onChainData.timestamp)}
                </Tag>
                <Tooltip label={props.cid}>
                  <Tag size="lg" variant="subtle" borderRadius="full">
                    {mask(props.cid)}
                  </Tag>
                </Tooltip>
              </HStack>

              <HStack gap={1} my={3}>
                {offChainData.metadata.tags.map((item) => {
                  return (<Tag key={item} textTransform={"capitalize"} variant="subtle" borderRadius="full">{item}</Tag>)
                })}
              </HStack>
            </Box>
          </GridItem>
          <GridItem colSpan={{ sm: 12, md: 12, lg: 3 }} align={"right"}>
            <Box py={3}>
              <HStack spacing={4}>
                <Tooltip label={"Click to like the post!"}>
                  <Tag key="md" colorScheme={liked ? "teal" : "gray"} variant="subtle"
                    cursor="pointer" borderRadius="full"
                    onClick={() => liked ? unlike() : like()}>
                    <TagLeftIcon boxSize="12px" as={StarIcon} />
                    <TagLabel>{onChainData.totalLikes.toNumber()}</TagLabel>
                  </Tag>
                </Tooltip>
                <Tooltip label={"Total donation the post recieved"}>
                  <Tag borderRadius="full">
                    {onChainData && (parseFloat(ethers.utils.formatEther(onChainData.totalTips)) || 0)}
                    <Image mx={2} boxSize="16px"
                      src="https://s3.us-east-2.amazonaws.com/assets.thetatoken.org/tokens/tfuel.png" alt="" />
                    Tipped
                  </Tag>
                </Tooltip>
              </HStack>
            </Box>
          </GridItem>
        </Grid>

        <Box dangerouslySetInnerHTML={{ __html: formatPost(offChainData.content.body) }} />

        <Box my={5}>
          <Center my={4}>
            <Heading size="md" fontWeight={600}>Like what you read?</Heading>
          </Center>

          <Grid templateColumns="repeat(12, 1fr)" gap={5}>
            <GridItem colSpan={{ md: 12, lg: 6 }} bg={backgroundColor} borderRadius={'10'}>
              <Heading size={"md"} my={4}>NFT</Heading>
              <HStack>
                <NFTOwnerList cid={props.cid}/>
                <NFTCollect cid={props.cid} />
              </HStack>
            </GridItem>
            <GridItem colSpan={{ md: 12, lg: 6 }}>
              <Image
                boxSize="64px"
                objectFit="cover"
                src={`https://robohash.org/${onChainData.author}?set=set4`}
                alt=""
              />
              <HStack>
                <Button bg={"main.100"} color={"white"} onClick={() => { }}>Follow</Button>
                <Tip cid={props.cid} />
              </HStack>
            </GridItem>
          </Grid>
        </Box>

      </GridItem>
      <GridItem colSpan={{ sm: 1, md: 1, lg: 3 }} />
    </Grid >
    : <Info status={"warning"} title={"Invalid"} description={"Invalid CID"} />}
  </>);
}

const formatPost = (body) => {
  if (!body) return "";

  const theme = "#2AB8E6";

  const start = 1;
  const end = 6;
  const headingSize = new Array(end - start).fill(undefined).map((d, i) => i + start);

  headingSize.map((size) => {
    body = body.replace(`<h${size}>`, `<h${size} style="font-size: ${16 + 3 * (end - size)}px">`);
  })

  body = body.replace(`<span class="ql-font-monospace">`, `<kbd class="chakra-text css-0">`);
  body = body.replace(`</span>`, `</kbd>`);

  return body;
}

export default StaticPropsDetail

export async function getitem(cid) {
  const offChainData = getOffchainData(cid);
  if (!offChainData) return null;

  if (response.ok) {
    let body = data.content.body.toString();
    // body = body.replace("<ul>", "<UnorderedList>");
    // body = body.replace("</ul>", "</UnorderedList>");
    // body = body.replace("<li>", "<ListItem>");
    // body = body.replace("</li>", "</ListItem>");

    const start = 1;
    const end = 6;
    const headingSize = new Array(end - start).fill(undefined).map((d, i) => i + start);

    headingSize.map((size) => {
      body = body.replace(`<h${size}>`, `<h${size} style="font-size: ${16 + 3 * (end - size)}px">`);
      // body = body.replace(`</h${size}>`, `</Heading>`);
    })

    body = body.replace(`<span class="ql-font-monospace">`, `<kbd class="chakra-text css-0">`);
    body = body.replace(`</span">`, `</kbd">`);


    data.content.body = body;
  }

  return {
    cid,
    data,
  };
}

// export async function getStaticProps({ params }) {
export async function getServerSideProps({ params }) {
  // bafybeiafzape4e7yufo4mdljqdf4thgkdong7ufr7jhw7djgdobomdsbxy
  // QmY9v5zidGi8HjZe916Mk3117rUUYkucdDAD3u24XZCoav
  // "QmSaHacz34z5DESf4y5nhopbYmNE7AVeFPTNjwyqR7DBNJ"
  const props = {
    cid: params.id,
    // offChainData: null
  }

  return {
    props: {
      props
    },
  };
}
