import { useEffect, useState } from "react";
import { useRouter } from "next/router"
import { useSDK, useAddress } from "@thirdweb-dev/react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import NFT from "../../components/NFT/NFT";
import {
  Button,
  Grid,
  GridItem,
  Center,
  Box,
  SimpleGrid,
  useColorModeValue,
  Stack,
  Text,
  HStack,

} from "@chakra-ui/react";

const WithStaticProps = ({ items }) => {
  const sdk = useSDK();
  const router = useRouter();
  const backgroundColor = useColorModeValue("white", "gray.900");
  const [nfts, setNFTs] = useState([]);
  const [totalNFTMinted, setTotalNFTMinted] = useState(0);

  useEffect(() => {
    (async () => {
      const contract = await sdk.getContractFromAbi(contractAddress, abi);

      const totalNFTs = await contract.call("idCounter");
      console.log(totalNFTs);

      if (!totalNFTs) return;
      const ids = Array(totalNFTs.toNumber()).fill(1).map((x, y) => x + y);
      console.log(ids);

      let totalNFTMinted = 0;
      await Promise.all(ids.map(async (tokenId) => {
        const totalOwners = await contract.call("totalOwners", [tokenId]);
        totalNFTMinted += totalOwners.toNumber();
      }));
      setTotalNFTMinted(totalNFTMinted);

      let nfts = [];
      await Promise.all(ids.map(async (tokenId) => {
        const nftInfo = await contract.call("nftInfo", [tokenId]);
        const nftInfoEdited = { ...nftInfo, tokenId: tokenId };
        nfts.push(nftInfoEdited);
      }));
      console.log(nfts)
      setNFTs(nfts);
    })();
  }, [sdk]);

  return (
    <>
      {/* {totalNFTMinted} */}

      <SimpleGrid minChildWidth="330px" spacing={3}>
        {nfts.map((nft, index) => {
          return (
            <Center key={index} py={12}>
              <Box
                role={"group"}
                p={6}
                maxW={"330px"}
                w={"full"}
                bg={backgroundColor}
                boxShadow={"2xl"}
                rounded={"lg"}
                pos={"relative"}
                zIndex={1}>
                <NFT tokenId={nft.tokenId} />

                <Stack pt={10} align={"center"}>
                  <HStack>
                    <Button colorScheme="twitter" variant={"outline"} onClick={() => router.push(`/posts/${nft.metadata}`)}>Read Post</Button>
                    <Button colorScheme="twitter" onClick={() => router.push(`/nft/${nft.tokenId}`)}>View NFT</Button>
                  </HStack>
                </Stack>
              </Box>
            </Center>
          )
        })}
      </SimpleGrid>
    </>
  )
}

export const getStaticProps = async () => {
  // Example for including static props in a Next.js function component page.
  // Don"t forge`t to include the respective types for any props passed into
  // the component.
  const items = true;
  return { props: { items } }
}

export default WithStaticProps
