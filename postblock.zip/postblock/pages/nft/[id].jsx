import {
  Box,
  Heading,
  Grid,
  GridItem,
  useToast,
  Container,
  Tooltip,
  Center,
} from "@chakra-ui/react"
import { mask } from "../../utils/mask";
import { useEffect, useState } from "react";
import { useSDK, useAddress } from "@thirdweb-dev/react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import { useRouter } from "next/router";
import NFT from "../../components/NFT/NFT";
import NFTOwner from "../../components/NFT/NFTOwner";
import NFTListing from "../../components/NFT/NFTListing";
import NFTDetails from "../../components/NFT/NFTDetails";
import NFTInfo from "../../components/NFT/NFTInfo";
import { getOffchainData } from "../../utils/utils";
const StaticPropsDetail = ({ props }) => {
  const sdk = useSDK();
  const toast = useToast();
  const address = useAddress();
  const router = useRouter();

  const [isValid, setIsValid] = useState(false);
  const [fullTitle, setFullTitle] = useState("");
  const [shortTitle, setShortTitle] = useState("");

  useEffect(() => {
    (async () => {
      let isTokenId = isNumeric(props.id);
      // if (!isTokenId) return;
      if (!isTokenId) return;

      setIsValid(true);

      const contract = await sdk.getContractFromAbi(contractAddress, abi);
      const nftInfo = await contract.call("nftInfo", [props.id]);
      if (!nftInfo) return;

      const offChainData = await getOffchainData(nftInfo.metadata);

      setShortTitle(`${mask(nftInfo.metadata)} #${props.id} (${offChainData.content.title})`);
      setFullTitle(`${nftInfo.metadata} #${props.id} (${offChainData.content.title})`);
    })();
  }, []);

  function isNumeric(value) {
    return /^\d+$/.test(value);
  }

  return (<>
    {isValid ?
      <Box mx={24}>
        <Grid templateColumns={{ md: "repeat(8, 1fr)", lg: "repeat(12, 1fr)" }}
          gap={6} columns={{ base: 1, md: 2, md: 3 }}>
          <GridItem colSpan={4}>
            <Center>
              <NFT tokenId={props.id} />
            </Center>
            <NFTDetails tokenId={props.id} />
          </GridItem>
          <GridItem colSpan={{ md: 4, lg: 8 }}>
            <Container my={4}>
              <Tooltip label={fullTitle} fontSize="md">
                <Heading size={"lg"} my={4}>{shortTitle}</Heading>
              </Tooltip>
              <NFTInfo tokenId={props.id} />

              <Heading size={"md"} my={4}>Owners</Heading>
              <NFTOwner tokenId={props.id} />

              <Heading size={"md"} my={4}>Available Listing</Heading>
              <NFTListing tokenId={props.id} />
            </Container>
          </GridItem>
        </Grid>
      </Box>
      : <>Invalid TokenID</>}
  </>);
}

export default StaticPropsDetail

export async function getServerSideProps({ params }) {
  const props = {
    id: params.id,
  }

  return {
    props: { props },
  };
}
