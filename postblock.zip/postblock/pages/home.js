import { useAddress, useSDK } from "@thirdweb-dev/react";
import { useEffect, useState } from "react";
import { abi } from "../utils/PostBlock/abi";
import { contractAddress } from "../utils/PostBlock/contract";
import { PostBlockService } from "../utils/services/PostBlockService";
import Post from "../components/Post";

export default function Home() {
    const address = useAddress();
    const sdk = useSDK();

    const [user, setUser] = useState([]);
    const [cids, setCids] = useState([]);

    useEffect(() => {
        (async () => {
            console.log(address);
            if (!address) return; 
            const contract = await sdk.getContractFromAbi(contractAddress, abi);
            console.log(contract);

            let user = await PostBlockService.getUserByAddress(contract, [address]);
            if (!user) return;
            setUser(user);

            let cids = [];
            if (user.following) {
                await Promise.all(user.following.map(async (addr) => {
                    let posts = await contract.call('getPost', [addr]);
                    console.log(posts);
                    if(!posts) return;
                
                    posts.map(async (item, index) => {
                        cids.push(item.cid);
                    });
                }));
            }
            setCids(cids);
        })();
    }, [address]);

    return (
        <div>
            {cids.map((cid, index) => {
                return (
                    <Post key={index} cid={cid} />
                )
            })}
        </div>
    );
}
