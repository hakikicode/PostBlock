import { Container } from "@chakra-ui/react";
import {
  useSDK,
  useAddress, 
  useChainId,
} from "@thirdweb-dev/react";
import { useEffect, useState } from "react";
import TextEditor from "../components/TextEditor";
import Info from "../components/Info";
import { ThetaTestnet } from "@thirdweb-dev/chains";
import ChainMismatch from "../components/ChainMismatch";

export default function Write({ items }) {
  const sdk = useSDK();
  const address = useAddress();
  const chainId = useChainId();
  const [chainIdMismatch, setChainIdMismatch] = useState(false);

  // const isMismatched = useNetworkMismatch(); // Doesn't work for some reason...
  // const { user, isLoggedIn } = useUser(); // Doesn"t work for some reason...

  useEffect(() => {
    (async () => {
      if (chainId && chainId !== ThetaTestnet.chainId) {
        setChainIdMismatch(true);
      }
    })();
  }, [chainId]);

  if (chainIdMismatch) return (<ChainMismatch />)

  return (
    <Container maxW={"6xl"}>
      {address
        ? <TextEditor items={items} />
        : <Info status={"error"} title={"Disconnected"} description={"Please connect to a Wallet"} />
      }
    </Container>
  );
}
