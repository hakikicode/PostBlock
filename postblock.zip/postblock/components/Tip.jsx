import { useRef, useState, useEffect } from "react";
import {
    Modal,
    ModalBody,
    ModalContent,
    ModalFooter,
    ModalHeader,
    ModalCloseButton,
    ModalOverlay,
    Button,
    InputGroup,
    Input,
    Select,
    Center,
    InputRightElement,
    useDisclosure,
    useToast,
} from "@chakra-ui/react";
import { CheckIcon } from "@chakra-ui/icons";
import { useAddress, ConnectWallet, useSDK } from "@thirdweb-dev/react";
import { abi } from "../utils/PostBlock/abi";
import { contractAddress } from "../utils/PostBlock/contract";
import { ethers } from "ethers";
import Notification from "./Notification";
import { useRouter } from "next/router";

export default function Tip({ cid }) {
    const { isOpen, onOpen, onClose } = useDisclosure()
    const address = useAddress();
    const sdk = useSDK();
    const toast = useToast();
    const router = useRouter();
    const notificationRef = useRef();

    const [tipAmt, setTipAmt] = useState(0);

    const tipPost = async () => {
        if(tipAmt <= 0) return;
        if(!address) return;

        notificationRef.current.onOpen("loading", "Tipping Post", "Please wait ...");

        let notificationStatus = "success";
        let notificationTitle = "Successful tip";
        let notificationMessage = `Tipped ${tipAmt} TFUEL`;

        try {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);
            const txOptions = {
                value: ethers.utils.parseEther(tipAmt),
            };

            const tx = await contract.call("tip", [cid], txOptions);
        }
        catch (err) {
            notificationStatus = "error";
            notificationTitle = "Error while tipping";
            notificationMessage = "Try again";
        }
    
        notificationRef.current.onOpen(notificationStatus, notificationTitle, notificationMessage);

        router.reload();
    }

    return (
        <>
            <Button onClick={onOpen}>Tip</Button>

                <Modal isOpen={isOpen} onClose={onClose} isCentered>
                    <ModalOverlay />
                    <ModalContent>
                        <ModalHeader>Tip (Thanks for the support)</ModalHeader>
                        <ModalCloseButton />
                        <ModalBody>
                            {address ? 
                            <InputGroup size="md">
                                <Input pr="6rem" type="number" placeholder="10"
                                    onChange={(e) => setTipAmt(e.target.value)}
                                />
                                <InputRightElement width="6rem">
                                    <Select placeholder="">
                                        <option value="TFUEL" defaultValue>TFUEL</option>
                                    </Select>
                                </InputRightElement>
                            </InputGroup>

                            : <Center>Connect To Wallet</Center>}
                        </ModalBody>

                        <ModalFooter>
                            {address                             
                                ? <Button rightIcon={<CheckIcon />} onClick={() => tipPost()}>Tip</Button>
                                : <ConnectWallet accentColor="blue" colorMode="dark" />
                            }
                        </ModalFooter>
                    </ModalContent>
                </Modal>
        <Notification ref={notificationRef}></Notification>
        </>
    )
}