import { Box, Heading, Link, Button } from "@chakra-ui/react";
import { CheckCircleIcon, WarningTwoIcon, InfoIcon, CloseIcon } from "@chakra-ui/icons";
import { useRouter } from "next/router"
import NextLink from "next/link"

export default function NewUser({ }) {
    const router = useRouter();

    return (
        <Box textAlign="center" px={6}>
            <Heading size="md" mb={6}>
                New here?
            </Heading>

            <Button type="button" onClick={() => router.push("/write")}>
                Get Started
            </Button>
        </Box>
    );
}