import {
    Alert,
    AlertTitle,
    AlertIcon,
    AlertDescription,
} from "@chakra-ui/alert"
import {
    Button,
    CloseButton,
    useDisclosure
} from "@chakra-ui/react"
import { useState, useEffect, forwardRef, useRef, useImperativeHandle } from "react";

function Notification({ }, ref) {
    // const { isOpen: isVisible, onClose, onOpen, } = useDisclosure({ defaultIsOpen: true });
    const [isVisible, setVisible] = useState(false);
    const [notificationStatus, setNotificationStatus] = useState("success");
    const [notificationTitle, setNotificationTitle] = useState("");
    const [notificationDescription, setNotificationDescription] = useState("");

    useImperativeHandle(ref, () => ({
        onOpen(status, title, description) {
            setVisible(true);
            setNotificationStatus(status);
            setNotificationTitle(title);
            setNotificationDescription(description);
        }
    }));

    const onClose = () => {
        setVisible(false);
    }

    return isVisible ? (
        <Alert status={notificationStatus}
            variant="solid"
            position="fixed"
            bottom={"32px"} right={"32px"}
            width={"33vw"}
            borderRadius={"full"}
        >
            <AlertIcon />
            <AlertTitle>{notificationTitle}</AlertTitle>
            <AlertDescription>{notificationDescription}</AlertDescription>
            <CloseButton right={-1} top={-1} onClick={onClose} />
        </Alert>
    ) : (<></>);
}

export default forwardRef(Notification);
