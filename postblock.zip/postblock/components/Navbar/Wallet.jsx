import { ReactNode, useState, useEffect } from "react";
import {
    Card,
    CardBody,
    CardFooter,
    Button,
    VStack,
    Link,
    Heading,
    Text,
    Image,
    HStack,
    useColorModeValue,
} from "@chakra-ui/react";
import { ExternalLinkIcon, PlusSquareIcon, RepeatIcon } from "@chakra-ui/icons";
// import { useWeb3, useSwitchNetwork } from "@3rdweb/hooks"
import { useAddress, useSDK } from "@thirdweb-dev/react";

export default function Wallet() {
    const address = useAddress();
    const sdk = useSDK();
    const cardBackground = useColorModeValue("white", "gray.900");

    const [balance, setBalance] = useState({
        symbol: "", name: "",
        decimals: null, value: null, displayValue: null
    });

    useEffect(() => {
        (async () => {
            try {
                const wallet = await sdk.wallet.balance();
                setBalance(wallet);
            } catch (e) {
                const wallet = await sdk.wallet.balance();
                setBalance(wallet);
            }
        })();
    }, [address]);

    return (
        <>
            {balance
                ? <Card maxW="md" bg={cardBackground}>
                    <CardBody>
                        <VStack>
                            <Heading size="md">Total Balance</Heading>
                            <HStack>
                                <Text>{balance.displayValue}</Text>
                                <Image boxSize="16px"
                                    src="https://s3.us-east-2.amazonaws.com/assets.thetatoken.org/tokens/tfuel.png" alt="" />
                            </HStack>
                        </VStack>
                    </CardBody>

                    <CardFooter
                        justify="space-between"
                        flexWrap="wrap"
                        sx={{ "& > button": { minW: "136px" } }}
                    >
                        <Button flex="1" variant="ghost">
                            <Link flex="1" variant="ghost"
                                href={`https://testnet-explorer.thetatoken.org/account/${address}`} isExternal>
                                <ExternalLinkIcon /> View on Explorer
                            </Link>
                        </Button>
                        <Button flex="1" variant="ghost" leftIcon={<PlusSquareIcon />}>
                            Add Funds
                        </Button>
                    </CardFooter>
                </Card>
                : <></>}
        </>
    );
}