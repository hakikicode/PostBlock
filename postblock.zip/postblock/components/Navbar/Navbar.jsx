import { useState, useEffect } from "react";
import {
  Box,
  HStack,
  Flex,
  Spacer,
  Link,
  Button,
  useDisclosure,
  useColorModeValue,
  useColorMode,
  Center,
  Container,
  useBreakpointValue,
} from "@chakra-ui/react";
import { ChatIcon, MoonIcon, SunIcon, Icon } from "@chakra-ui/icons";
import { useAddress } from "@thirdweb-dev/react";
import { useRouter } from "next/router";
import { ConnectWallet } from "@thirdweb-dev/react";
// import UserMenu from "./UserMenu";
import UserDrawer from "./UserDrawer";

const Links = [
  { title: "Home", url: "/home" },
  { title: "Start posting", url: "/publisher" },
  { title: "Start advertising", url: "/advertiser" },
  { title: "NFT", url: "/nft" }
];

const NavLink = ({ children, url }) => (
  <Link
    px={6}
    py={1}
    rounded={"md"}
    _hover={{
      textDecoration: "none",
      textColor: "main.100"
    }}
    href={url
    }>
    {children}
  </Link>
);

export default function Navbar() {
  const address = useAddress();
  const router = useRouter();
  const isDesktop = useBreakpointValue({ base: false, lg: true })

  const navBg = useColorModeValue("white", "gray.800");
  const { colorMode, toggleColorMode } = useColorMode();
  const { isOpen, onOpen, onClose } = useDisclosure();

  const [prevScrollPos, setPrevScrollPos] = useState(0);
  const [visible, setVisible] = useState(true)
  const handleScroll = () => {
    const currentScrollPos = window.scrollY

    if (currentScrollPos > prevScrollPos) {
      setVisible(false)
    } else {
      setVisible(true)
    }

    setPrevScrollPos(currentScrollPos)
  }

  useEffect(() => {
    (async () => {
      // Async stuff goes here
    })();
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll)
  })

  return (
    <Flex gap="2" height={20} fontWeight={600}
      w="100%" zIndex={1100}
      // backdropFilter="auto" backdropBlur="8px"
      bg={navBg}
      style={visible ? { position: "sticky", top: 0 } : { visibility: "hidden" }}
    >
      <Center>
        <Container>
          <Box id="logo">
            <HStack cursor={"pointer"} onClick={() => router.push(`/`)}>
              <Icon boxSize={9} as={ChatIcon} color={"main.100"} />
              <div>PostBlock</div>
            </HStack>
          </Box>
        </Container>
      </Center>
      <Spacer />
      <Center>
        <Box id="links">
          <HStack
            as={"nav"}
            spacing={4}
            display={{ base: "none", md: "flex" }}>
            {Links.map((link) => (
              <NavLink key={link.title} url={link.url}>{link.title}</NavLink>
            ))}
          </HStack>
        </Box>
      </Center>
      <Spacer />
      <Center>
        <Container>
          <Box id="cta">
            <HStack spacing="3">
              <Button onClick={toggleColorMode} colorScheme="none" textColor="gray"
                _hover={{
                  textDecoration: "none",
                  textColor: "main.100"
                }}>
                {colorMode === "light" ? <MoonIcon /> : <SunIcon />}
              </Button>
              {address ?
                <UserDrawer /> :
                <ConnectWallet accentColor="blue" colorMode="dark" />
              }
            </HStack>
          </Box>
        </Container>
      </Center>
    </Flex>
  );
}