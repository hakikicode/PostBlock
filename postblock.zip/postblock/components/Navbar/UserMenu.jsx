import {
  Button,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  MenuDivider,
} from "@chakra-ui/react";
// import { useWeb3, useSwitchNetwork } from "@3rdweb/hooks"
import { useAddress, useMetamask, useDisconnect } from "@thirdweb-dev/react";
import Identicon from "../Identicon";

const Links = [
  { title: "Home", url: "/" },
  { title: "Trending", url: "/publish" },
  { title: "Disconnect", url: "/publish" }
];


export default function UserMenu() {
  const disconnect = useDisconnect();
  const address = useAddress();

  return (
    <Menu>
        <MenuButton
          as={Button}
          rounded={"full"}
          variant={"link"}
          cursor={"pointer"}
          minW={0}>
            <Identicon seed={address} scale={5} borderRadius={100}></Identicon>
        </MenuButton>
        <MenuList>
            <MenuItem>My Published</MenuItem>
            <MenuDivider />
            <MenuItem onClick={disconnect}>Disconnect</MenuItem>
        </MenuList>
        </Menu>
  );
}