import { useRef, useEffect } from "react";
import {
    Drawer,
    DrawerBody,
    DrawerFooter,
    DrawerHeader,
    DrawerOverlay,
    DrawerContent,
    DrawerCloseButton,
    Button,
    Text,
    Image,
    useDisclosure,
    useColorModeValue,
    HStack,
} from "@chakra-ui/react";
import { ArrowForwardIcon } from "@chakra-ui/icons";
import { useAddress, useDisconnect } from "@thirdweb-dev/react";
import ProfileSetting from "../Settings/ProfileSetting";
import { web3 } from "../../utils/web3";
import Wallet from "./Wallet";

export default function UserDrawer() {
    const address = useAddress();
    const disconnect = useDisconnect();

    const btnRef = useRef();
    const { isOpen, onOpen, onClose } = useDisclosure();

    useEffect(() => {
        (async () => {
        })();
    }, []);

    return (
        <>
            <div ref={btnRef} onClick={onOpen}>
                <Image
                    cursor={"pointer"}
                    boxSize="36px"
                    objectFit="cover"
                    src={`https://robohash.org/${address}?set=set4`}
                    alt=""
                />
            </div>
            <Drawer
                isOpen={isOpen}
                placement="right"
                onClose={onClose}
                finalFocusRef={btnRef}
            >
                <DrawerOverlay />
                <DrawerContent>
                    <DrawerCloseButton />
                    <DrawerHeader bg={useColorModeValue("white", "gray.900")}>
                        <HStack>
                            <Image
                                cursor={"pointer"}
                                boxSize="36px"
                                objectFit="cover"
                                src={`https://robohash.org/${address}?set=set4`}
                                alt=""
                            />
                            <Text>{web3.mask(address)}</Text>
                        </HStack>
                    </DrawerHeader>
                    <DrawerBody>
                        <Wallet />
                        <ProfileSetting />
                    </DrawerBody>
                    <DrawerFooter>
                        <Button variant="outline" colorScheme="messenger" mr={3} onClick={onClose}>
                            Cancel
                        </Button>
                        <Button rightIcon={<ArrowForwardIcon />} colorScheme="gray" onClick={disconnect}>
                            Disconnect
                        </Button>
                    </DrawerFooter>
                </DrawerContent>
            </Drawer>
        </>
    )
}