import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import { useState, useRef } from "react";
import {
  Button,
  ButtonGroup,
  Box,
  Divider,
  Tooltip,
  Card,
  CardHeader,
  Heading,
  CardBody,
  Text,
  StackDivider,
  Grid,
  GridItem,
  FormLabel,
  FormControl,
  Input,
  Tag,
  Flex,
  HStack,
  Spacer,
  Code,
  Center,
  StatGroup,
  Stat,
  StatLabel,
  StatNumber,
  IconButton,
  useClipboard,
} from "@chakra-ui/react"
import { SmallCloseIcon, ExternalLinkIcon } from "@chakra-ui/icons"
import {
  useConnect, useMetamask, useSDK, useAddress,
  useStorage, useStorageUpload
} from "@thirdweb-dev/react";
import { abi } from "../utils/PostBlock/abi";
import { contractAddress } from "../utils/PostBlock/contract";
import { mask } from "../utils/mask";
import * as constants from "../utils/constants";
import Notification from "./Notification";
import NFTForm from "./NFTForm";

const QuillNoSSRWrapper = dynamic(import("react-quill"), { ssr: false })

const modules = {
  toolbar: [
    [{ header: "1" }, { header: "2" }, { header: "3" }, { font: [] }],
    [{ size: [] }],
    ["bold", "italic", "underline", "strike", "blockquote"],
    [{ "script": "sub" }, { "script": "super" }],
    [{ "direction": "rtl" }],
    [
      { list: "ordered" },
      { list: "bullet" },
      { indent: "-1" },
      { indent: "+1" },
    ],
    ["link", "image", "video"],
    ["clean"],
  ],
  clipboard: {
    // toggle to add extra line breaks when pasting HTML:
    matchVisual: false,
  },
}

function TextEditor({ items }) {
  const sdk = useSDK();
  const address = useAddress();
  const router = useRouter();
  const { mutateAsync: upload } = useStorageUpload();
  const { onCopy, value, setValue, hasCopied } = useClipboard("");

  const [content, setContent] = useState("");

  const [postTitle, setPostTitle] = useState("");   // Title Input
  const [tag, setTag] = useState("");               // Tag Input
  const [postTags, setPostTags] = useState([]);     // Tags
  const [postTheme, setPostTheme] = useState("#0078FF");   // Color Picker

  const [isUploading, setIsUploading] = useState(false);   // Controls submit btn animation

  const [postCID, setPostCID] = useState("");
  const [postTX, setPostTX] = useState("");

  const notificationRef = useRef();
  const nftFormRef = useRef();

  // Styles
  const formLabelStyle = {
    fontWeight: 600,
  }
  const generatePostBlockData = (address, title, content, imageCID, tags, theme) => {
    if (!address) return null;
    if (!title) return null;
    if (!content) return null;

    return {
      content: {
        title: title,
        body: content,
        image: imageCID,
      },
      metadata: {
        tags: tags,
        theme: theme,
        creation: new Date().toISOString(),
        author: address
      }
    };
  }

  const uploadEdgeStore = async (data, contentType) => {
    // Requires Accepting Signature Request
    if (!window.ethereum) {
      throw 'wallet not installed';
    }

    const timestamp = Date.now().toString();
    const msg = 'Theta EdgeStore Call ' + timestamp;

    const sig = await window.ethereum.request({
      method: 'personal_sign',
      params: [msg, address],
    });

    const auth_token = timestamp + "." + address + "." + sig;
    // console.log(auth_token);

    var myHeaders = new Headers();
    myHeaders.append("x-theta-edgestore-auth", auth_token);

    var formdata = new FormData();

    let formDataData = null;
    switch(contentType) {
      case "application/json":
        formDataData = new Blob([JSON.stringify(data)], { type: contentType })
        break;
      case "image/png":
        formDataData = data;
        break;
      default:
    }
    if (!formDataData) return "";

    formdata.append("file", formDataData);

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: formdata,
      redirect: 'follow'
    };

    const response = await fetch("https://api.thetaedgestore.com/api/v2/data", requestOptions);
    const result = await response.json(); 
    // console.log(result);
    return result.key;
  }

  const uploadForm = async () => {
    // Upload image to EdgeStore to get cid for the post
    const imgCID = await uploadEdgeStore(image, "image/png");

    // Get the JSON data from the form that
    const data = generatePostBlockData(address, postTitle, content, imgCID, postTags, postTheme);
    if (!data) {
      notificationRef.current.onOpen("error", "Error", "Please fill all the fields");
      setIsUploading(false);
      return;
    }

    // Upload to EdgeStore
    const postCID = await uploadEdgeStore(data, "application/json");

    return postCID;
  }

  const addPostTag = (e) => {
    if (tag == "") return;
    if (postTags.length > 10 || postTags.includes(tag)) return;
    setPostTags(oldArray => [...oldArray, tag]);
  }

  const deletePostTag = (value) => {
    setPostTags(postTags.filter(item => item !== value));
  }

  const uploadDraft = async () => {
    const notificationStatus = "loading";
    const notificationTitle = "Uploading ...";
    const notificationDescription = "Please wait ...";

    notificationRef.current.onOpen(notificationStatus, notificationTitle, notificationDescription);
    setIsUploading(true);

    // Upload form info to EdgeStore to get cid
    const cid = await uploadForm();

    notificationRef.current.onOpen("success", "Uploading ...", "Please wait ...");
    setIsUploading(false);
  }

  const uploadToBlockChain = async (event) => {
    setIsUploading(true);

    // Upload to EdgeStore
    let notificationStatus = "loading";
    let notificationTitle = "Uploading to EdgeStore";
    let notificationDescription = "Please wait ...";
    notificationRef.current.onOpen(notificationStatus, notificationTitle, notificationDescription);
    const cid = await uploadForm();
    if (!cid) return;

    // Upload to Theta Blockchain
    notificationStatus = "loading";
    notificationTitle = "Uploading to Blockchain";
    notificationDescription = "Please wait ...";
    notificationRef.current.onOpen(notificationStatus, notificationTitle, notificationDescription);
    const contract = await sdk.getContractFromAbi(contractAddress, abi);
    const { supply, price } = nftFormRef.current.getNFTInfo();

    try {
      const tx = await contract.call("publish", [cid, supply, price]);
      const receipt = tx.receipt;
      setPostCID(cid);
      setPostTX(receipt.transactionHash);
      notificationStatus = "success";
      notificationTitle = "Success";
      notificationDescription = "Post uploaded";
    } catch (error) {
      notificationStatus = "error";
      notificationTitle = "Failed to process on chain";
      notificationDescription = "error";
    }

    notificationRef.current.onOpen(notificationStatus, notificationTitle, notificationDescription);
    setIsUploading(false);
  }

  const [image, setImage] = useState(null);
  const [imageSrc, setImageSrc] = useState(null);
  const loadFile = (event) => {
    if (event.target.files && event.target.files[0]) {
      const i = event.target.files[0];

      setImage(i);
      setImageSrc(URL.createObjectURL(i));
    }
  }

  return (
    <Box h="calc(100vh)" >
      <form>
        <Grid templateColumns="repeat(12, 1fr)" gap={3} mb={4}>
          <GridItem colSpan={12}>
            <Flex>
              <Box py={3}>
              </Box>
              <Spacer />
              <Box py={3}>
                <ButtonGroup gap="1">
                  <Button
                    isLoading={isUploading}
                    loadingText="Submitting"
                    colorScheme="gray"
                    onClick={() => uploadDraft()}
                    borderRadius={".5rem"}
                  >
                    Draft
                  </Button>
                  <Button
                    isLoading={isUploading}
                    onClick={() => uploadToBlockChain()}
                    loadingText="Submitting"
                    colorScheme="messenger"
                    borderRadius={".5rem"}
                  >
                    Publish
                  </Button>
                </ButtonGroup>
              </Box>
            </Flex>
          </GridItem>
        </Grid>

        <Grid templateColumns="repeat(12, 1fr)" gap={3} mb={4}>
          <GridItem colSpan={10}>
            <FormControl isRequired={true}>
              <FormLabel fontWeight={formLabelStyle.fontWeight}>Title</FormLabel>
              <Input
                type="text"
                placeholder="Choose a title"
                onChange={(e) => setPostTitle(e.target.value)}
                my={2} py={6} borderRadius={10}
              />
            </FormControl>
          </ GridItem>
          <GridItem colSpan={2}>
            <FormLabel fontWeight={600}>Theme</FormLabel>
            <Input type="color"
              bg={postTheme}
              value={postTheme}
              onChange={(e) => setPostTheme(e.target.value)}
              my={2} py={6} borderRadius={10}
            />
          </ GridItem>
        </Grid>

        <FormControl>
          <FormLabel fontWeight={formLabelStyle.fontWeight}>Tags</FormLabel>
          <Input
            type="text"
            placeholder="Enter Tag"
            onChange={(e) => setTag(e.target.value)}
            my={2} py={6} borderRadius={10}
          />
          <Button id="addTag" colorScheme="messenger" variant="outline"
            onClick={(e) => addPostTag(e)} my={2}>
            Add Tag
          </Button>
          <div>
            {postTags.map((item, index) => {
              return (
                <Tag key={index} mx={3}
                  size={"md"} variant="solid"
                  colorScheme="orange" textTransform={"capitalize"}
                >
                  {item}
                  <SmallCloseIcon ml={2} onClick={(e) => deletePostTag(item)} />
                </Tag>
              )
            })}
          </div>
        </FormControl>

        <FormControl isRequired={true}>
          <FormLabel fontWeight={formLabelStyle.fontWeight}>Image</FormLabel>
          <Input
            id="file-upload"
            type="file"
            accept="image/png, image/gif, image/jpeg"
            onChange={(e) => loadFile(e)}
            visibility={"collapse"}
          />
          <label htmlFor="file-upload" style={{ width: "100%", backgroundColor: "red" }} >
            <Center border="1px solid" borderColor="gray.200"
              bgImage={imageSrc}
              bgPosition="center"
              bgRepeat="no-repeat"
              bgSize="cover"
              my={5} borderRadius={10} w={"100%"} h={"20vh"}>
              Upload Image File
            </Center>
          </label>
        </FormControl>

        <FormControl isRequired={true}>
          <FormLabel fontWeight={formLabelStyle.fontWeight}>Contents</FormLabel>
          <QuillNoSSRWrapper onChange={setContent} modules={modules} theme="snow" />
        </FormControl>

        <Box my={4}>
          <NFTForm ref={nftFormRef} />
        </Box>

        <Divider my={12} />

        <StatGroup py={"12"}>
          <Stat>
            <StatLabel>Post CID</StatLabel>
            <Tooltip label={"Click to copy"} fontSize="md">
              <StatNumber onClick={onCopy}>{hasCopied ? "Copied!" : mask(postCID)}</StatNumber>
            </Tooltip>
            {postCID ?
              <Button
                variant="ghost"
                // colorScheme="teal"
                aria-label=""
                fontSize="16px"
                onClick={() => router.push(`/posts/${postCID}`)}
              >View Post</Button>
              : <></>
            }
          </Stat>

          <Stat>
            <StatLabel>Post Tx</StatLabel>
            <Tooltip label={"Click to copy"} fontSize="md">
              <StatNumber onClick={onCopy}>{hasCopied ? "Copied!" : mask(postTX)}</StatNumber>
            </Tooltip>
          </Stat>

          <Stat>
            <StatLabel>NFT Tx</StatLabel>
            <StatNumber>Coming Soon</StatNumber>
          </Stat>
        </StatGroup>

      </form>

      <Notification ref={notificationRef} />
    </Box>
  )
}

export default TextEditor
