import {
  Heading,
  Avatar,
  Box,
  Center,
  Text,
  Stack,
  Button,
  Link,
  Badge,
  useToast,
  useColorModeValue,
} from "@chakra-ui/react";
import { mask } from "../utils/mask";
import { abi } from "../utils/PostBlock/abi";
import { contractAddress } from "../utils/PostBlock/contract";
import { useSDK, useMetamask, useConnect, useContract, useAddress } from "@thirdweb-dev/react";
import { useEffect, useState, useRef } from "react";
import { BigNumber } from "ethers";
import Notification from "./Notification";
import { PostBlockService } from "../utils/services/PostBlockService";
import { useRouter } from "next/router";

export default function Profile({ address }) {
  const sdk = useSDK();
  const toast = useToast();
  const myAddress = useAddress();
  const notificationRef = useRef();
  const router = useRouter();

  const [user, setUser] = useState(null);
  const [me, setMe] = useState(null);
  const [totalPosts, setTotalPosts] = useState(0);
  const [totalFollowers, setTotalFollowers] = useState(0);

  const [isFollowing, setIsFollowing] = useState(false);

  const follow = async () => {
    notificationRef.current.onOpen("loading", "Updating follow status ...", "Please wait ...");

    if (!myAddress || !user) {
      toast({ title: "Connect to wallet", status: "warning", position: "bottom-right", isClosable: true });
      return;
    }

    const contract = await sdk.getContractFromAbi(contractAddress, abi);

    let notificationTitle = "Followed";
    let notificationMessage = `You are now following ${user.name}`;
    let notificationStatus = "success";

    try {
      const tx = await contract.call("follow", [address]);
      const receipt = tx.receipt;
    }
    catch (e) {
      notificationTitle = "Error";
      notificationMessage = "Error. You may already be following user.";
      notificationStatus = "error";
    }

    notificationRef.current.onOpen(notificationStatus, notificationTitle, notificationMessage);
    await updateFollowingStatus();
    await updateUserFollowers();
  }

  const unfollow = async () => {
    if (!myAddress) {
      toast({ title: "Connect to wallet", status: "warning", position: "bottom-right", isClosable: true });
      return;
    }

    const contract = await sdk.getContractFromAbi(contractAddress, abi);

    try {
      const tx = await contract.call("unfollow", [address]);
      const receipt = tx.receipt;
    }
    catch (e) {
      console.log(e);
      toast({ title: "Error. You may not be following user.", status: "error", position: "bottom-right", isClosable: true });
    }

    await updateFollowingStatus();
    await updateUserFollowers();

  }

  const updateUserFollowers = async () => {
    if (!address) return;

    const contract = await sdk.getContractFromAbi(contractAddress, abi);
    const totalFollowers = await contract.call("totalMembers", [address]);
    setTotalFollowers(totalFollowers.toNumber());
  }

  const updateFollowingStatus = async () => {
    if (!address || !myAddress) return;

    const contract = await sdk.getContractFromAbi(contractAddress, abi);

    const isFollowing = await contract.call("blogMembers", [address, myAddress,]);
    console.log(isFollowing);
    setIsFollowing(isFollowing);
  };

  useEffect(() => {
    (async () => {
      const contract = await sdk.getContractFromAbi(contractAddress, abi);

      let user = await PostBlockService.getUserByAddress(contract, [address]);
      if (user) setUser(user);

      let me = await PostBlockService.getUserByAddress(contract, [myAddress]);
      if (me) setMe(me);
      
      const totalPosts = await contract.call("getUserPosts", [address]);
      setTotalPosts(totalPosts.toNumber());

      await updateUserFollowers();
      await updateFollowingStatus();
    })();
  }, []);

  return (
    <Center py={6} w={"full"}>
      <Box
        maxW={"320px"}
        w={"320px"}
        bg={useColorModeValue("white", "gray.900")}
        boxShadow={"2xl"}
        rounded={"lg"}
        p={6}
        textAlign={"center"}>
        <Avatar
          size={"xl"}
          src={`https://robohash.org/${address}?set=set4`}
          alt={""}
          mb={4} pos={"relative"}
          _after={{
            content: '""',
            w: 4,
            h: 4,
            bg: "green.300",
            border: "2px solid white",
            rounded: "full",
            pos: "absolute",
            bottom: 0,
            right: 3,
          }}
        />
        <Heading fontSize={"2xl"} fontFamily={"body"}>
          {user && user.name ? user.name : mask(address)}
        </Heading>
        <Text fontWeight={600} color={"gray.500"} mb={4}>
          {mask(address)}
        </Text>
        <Text
          textAlign={"center"}
          color={useColorModeValue("gray.700", "gray.400")}
          px={3}>
          {user && user.description ? user.description : ""}
        </Text>

        <Stack direction={"row"} justify={"center"} spacing={6} mt={6}>
          <Stack spacing={0} align={"center"}>
            <Text fontWeight={600}>{totalPosts || 0}</Text>
            <Text fontSize={"sm"} color={"gray.500"}>Posts</Text>
          </Stack>
          <Stack spacing={0} align={"center"}>
            <Text fontWeight={600}>{totalFollowers || 0}</Text>
            <Text fontSize={"sm"} color={"gray.500"}>Followers</Text>
          </Stack>
        </Stack>

        <Stack mt={8} direction={"row"} spacing={4}>
          {(user && user.social)
            ? <Button flex={1} fontSize={"sm"} _focus={{ bg: "gray.200", }}>
              Twitter
            </Button>
            : <></>}
          {(user && me)
            ? <Button flex={1} fontSize={"sm"} bg={"blue.400"} color={"white"}
              _hover={{ bg: "blue.500", }} _focus={{ bg: "blue.500", }}
              onClick={() => isFollowing ? unfollow() : follow()}
            >
              {isFollowing ? "Unfollow" : "Follow"}
            </Button>
            : <Button flex={1} fontSize={"sm"} bg={"blue.400"} color={"white"}
              _hover={{ bg: "blue.500", }} _focus={{ bg: "blue.500", }}
              onClick={() => router.push('/write')}
            >
              Publish a post to follow.
            </Button>}
        </Stack>
      </Box>

      <Notification ref={notificationRef} />
    </Center>
  );
}