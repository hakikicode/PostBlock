import * as React from "react"
import { useState, forwardRef, useRef, useImperativeHandle } from "react";
import {
    Button,
    SlideFade,
    Flex,
    Text,
    FormControl,
    FormLabel,
    Input,
    FormHelperText,
    Tooltip,
    useDisclosure,
    HStack,
} from "@chakra-ui/react"
import { InfoOutlineIcon } from "@chakra-ui/icons"
import {
    useConnect, useMetamask, useSDK, useAddress,
    useStorage, useStorageUpload
} from "@thirdweb-dev/react";
import { abi } from "../utils/PostBlockPBC20/abi";
import { contractAddress } from "../utils/PostBlockPBC20/contract";

function NFTForm({ }, ref) {
    const sdk = useSDK();
    const address = useAddress();
    const { isOpen, onToggle } = useDisclosure();

    const [supply, setSupply] = useState(1);
    const [price, setPrice] = useState(0);

    useImperativeHandle(ref, () => ({

        getNFTInfo: () => {
            return { supply, price }
        }

    }));

    return (
        <Flex>
            <FormControl mr="5%">
                <FormLabel fontWeight={600}>Supply</FormLabel>
                <Input type="number" placeholder="Supply" defaultValue={supply}
                    onChange={(e) => setSupply(e.target.value)} />
            </FormControl>

            <FormControl>
                <FormLabel fontWeight={600}>Price</FormLabel>
                <Input type="number" placeholder="Price" defaultValue={price}
                    onChange={(e) => setPrice(e.target.value)} />
            </FormControl>
        </Flex>
    )
}

export default forwardRef(NFTForm);