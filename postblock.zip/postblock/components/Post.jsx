import {
    Box,
    Image,
    Center,
    Heading,
    Text,
    Stack,
    Avatar,
    Tag,
    Link,
    Tooltip,
    useColorModeValue,
    Container,
} from "@chakra-ui/react";
import { useEffect, useState } from "react";
import { abi } from "../utils/PostBlock/abi";
import { contractAddress } from "../utils/PostBlock/contract";
import { useSDK } from "@thirdweb-dev/react";
import { EMPTYONCHAINDATA, EMPTYOFFCHAINDATA } from "../utils/constants";
import { getOffchainData, getImageFromData, isValidTxHash } from "../utils/utils";
import { mask } from "../utils/mask";
import { formatTimestamp } from "../utils/datepipe";
import { PostBlockService } from "../utils/services/PostBlockService";
import { useRouter } from "next/router";

export default function Post({ cid }) {
    const sdk = useSDK();
    const router = useRouter();
    const postBackground = useColorModeValue("white", "gray.900");
    const headerColor = useColorModeValue("gray.700", "white");

    const [user, setUser] = useState(null);
    const [onChainData, setOnChainData] = useState(EMPTYONCHAINDATA);
    const [offChainData, setOffChainData] = useState(EMPTYOFFCHAINDATA);

    useEffect(() => {
        (async () => {
            if (!cid || !isValidTxHash(cid)) return;
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            const onChainData = await contract.call("posts", [cid]);
            if (!onChainData) return;
            setOnChainData(onChainData);

            const offChainData = await getOffchainData(cid);
            if (!offChainData) return;
            setOffChainData(offChainData);

            let user = await PostBlockService.getUserByAddress(contract, [onChainData.author]);
            if (user) setUser(user);
        })();

    }, []);


    function extractContent(s) {
        var span = document.createElement("span");
        span.innerHTML = s;
        return span.textContent || span.innerText;
    };

    return (
        <Container>
            {(Object.keys(offChainData).length !== 0 && Object.keys(onChainData).length !== 0)
                ?
                <Link href={`/posts/${cid}`}>
                    <Center py={6}>
                        <Box
                            maxW={"445px"}
                            w={"full"}
                            bg={postBackground}
                            boxShadow={"2xl"}
                            rounded={"md"}
                            overflow={"hidden"}>
                            <Image
                                src={getImageFromData(offChainData)}
                                alt="" layout={"fill"} h={"240px"} w={"full"}
                                objectFit={"cover"}
                            />
                            <Box p={6}>
                                <Stack>
                                    <Text
                                        color={"green.500"}
                                        textTransform={"uppercase"}
                                        fontWeight={800}
                                        fontSize={"sm"}
                                        letterSpacing={1.1}>
                                        {mask(cid)}
                                    </Text>
                                    <Heading
                                        color={headerColor}
                                        fontSize={"2xl"}
                                        fontFamily={"body"}>
                                        {offChainData.content.title}
                                    </Heading>
                                    <Text color={"gray.500"}>
                                        {extractContent(offChainData.content.body).substring(0, 250)}
                                    </Text>

                                </Stack>
                                <Box mt={4}>
                                    {offChainData.metadata.tags.map((tag, index) => {
                                        return (
                                            <Tag key={index} mr={3}
                                                size={"md"} variant="solid"
                                                colorScheme="orange" textTransform={"capitalize"}
                                            >
                                                {tag}
                                            </Tag>
                                        );
                                    })}
                                </Box>
                                <Stack mt={6} direction={"row"} spacing={4} align={"center"}>
                                    <Avatar
                                        src={`https://robohash.org/${onChainData.author}?set=set4`}
                                        alt={"Author"} onClick={() => router.push(`/users/${onChainData.author}`)}
                                    />
                                    <Stack direction={"column"} spacing={0} fontSize={"sm"}>
                                        <Tooltip label={onChainData.author} fontSize="md">
                                            <Text fontWeight={600}>{(user && user.name) ? user.name : mask(onChainData.author)}</Text>
                                        </Tooltip>
                                        {/* <Text fontWeight={600}>{mask(onChainData.author)}</Text> */}
                                        <Text color={"gray.500"}>{formatTimestamp(onChainData.timestamp)}</Text>
                                    </Stack>
                                </Stack>
                            </Box>
                        </Box>
                    </Center>
                </Link>
                : <> </>}
        </Container>
    );
}