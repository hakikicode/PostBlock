import {
    Grid,
    GridItem,
    Box,
    SimpleGrid,
    Container,
} from "@chakra-ui/react"
import { InfoOutlineIcon } from "@chakra-ui/icons"
import { useState, useEffect } from "react";
import { useSDK, useAddress, } from "@thirdweb-dev/react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import NFT from "./NFT";
import { useRouter } from "next/router";

export default function NFTCollection({ address }) {
    const sdk = useSDK();
    const router = useRouter();

    const [tokenIds, setTokenIds] = useState([]);

    useEffect(() => {
        (async () => {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            // List of BigNumber
            const nftIds = await contract.call("getAllNFT", [address]);
            const tokenIds = [];
            nftIds.forEach((nftId) => {
                if (nftId.toNumber() == 0) return;
                tokenIds.push(nftId.toNumber());
            })

            setTokenIds(tokenIds);
        })();
    }, []);

    return (
        <>
            <SimpleGrid minChildWidth='120px' spacing='40px'>
                {tokenIds.map((tokenId, index) => {
                    return (
                        <Container key={index} >
                            <Box cursor={"pointer"} onClick={() => router.push(`/nft/${tokenId}`)}>
                                <NFT tokenId={tokenId} />
                            </Box>
                        </Container>
                    )
                })}
            </SimpleGrid>
        </>
    )
}
