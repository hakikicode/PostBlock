import { useRef, useState, useEffect, use } from "react";
import {
    Modal,
    ModalBody,
    ModalContent,
    ModalFooter,
    ModalHeader,
    ModalCloseButton,
    ModalOverlay,
    Button,
    InputGroup,
    Input,
    Select,
    Center,
    InputRightElement,
    useDisclosure,
    useToast,
    Avatar,
} from "@chakra-ui/react";
import { CheckIcon } from "@chakra-ui/icons";
import { useAddress, ConnectWallet, useSDK } from "@thirdweb-dev/react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import { ethers } from "ethers";
import Notification from "../Notification";
import { useRouter } from "next/router";

export default function NFTList({ tokenId }) {
    const { isOpen, onOpen, onClose } = useDisclosure()
    const address = useAddress();
    const sdk = useSDK();
    const toast = useToast();
    const notificationRef = useRef();
    const router = useRouter();
    
    const [listAmt, setListAmt] = useState(0);

    const listNFT = async () => {
        if (listAmt <= 0) return;
        if (!address) return;

        notificationRef.current.onOpen("loading", "Listing NFT", "Please wait ...");

        try {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            // List NFT
            const tx = await contract.call("list", [tokenId, listAmt]);

            notificationRef.current.onOpen("success", "Successful listing", `Listed for ${listAmt}`);
        }
        catch (err) {
            notificationRef.current.onOpen("error", "Error while listing", "Try again");
        }

        router.reload(window.location.pathname);
    }

    return (
        <>
            <Button onClick={onOpen}>List</Button>
            <Modal isOpen={isOpen} onClose={onClose} isCentered>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader>List NFT</ModalHeader>
                    <ModalCloseButton />
                    <ModalBody>
                        {address ?
                            <InputGroup size="md">
                                <Input pr="6rem" type="number" placeholder="10"
                                    onChange={(e) => setListAmt(e.target.value)}
                                />
                                <InputRightElement width="6rem">
                                    <Select placeholder="">
                                        <option value="TFUEL" defaultValue>TFUEL</option>
                                    </Select>
                                </InputRightElement>
                            </InputGroup>

                            : <Center>Connect To Wallet</Center>}
                    </ModalBody>

                    <ModalFooter>
                        {address
                            ? <Button rightIcon={<CheckIcon />} onClick={() => listNFT()}>List</Button>
                            : <ConnectWallet accentColor="blue" colorMode="dark" />
                        }
                    </ModalFooter>
                </ModalContent>
            </Modal>

            <Notification ref={notificationRef} />
        </>
    )
}