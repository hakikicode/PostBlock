import { useRef, useState, useEffect } from "react";
import {
    Modal,
    ModalBody,
    ModalContent,
    ModalFooter,
    ModalHeader,
    ModalCloseButton,
    ModalOverlay,
    Button,
    Tooltip,
    InputGroup,
    Circle,
    Image,
    TableContainer,
    Table,
    Thead,
    Tbody,
    Tr,
    Th,
    Td,
    TableCaption,
    useColorModeValue,
    useDisclosure,
    useToast,
} from "@chakra-ui/react";
import { CheckIcon } from "@chakra-ui/icons";
import { useAddress, ConnectWallet, useSDK } from "@thirdweb-dev/react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import { ethers } from "ethers";
import { useRouter } from "next/router";
import { nullAddress } from "../../utils/constants";
import { mask } from "../../utils/mask";

export default function NFTOwnerList({ cid }) {
    const { isOpen, onOpen, onClose } = useDisclosure();
    const address = useAddress();
    const sdk = useSDK();
    const router = useRouter();

    const [owners, setOwners] = useState([]);

    useEffect(() => {
        (async () => {
            if (!cid) return;
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            const tokenId = await contract.call("postNFTLookup", [cid]);
            if (tokenId.toNumber() == 0) return;

            let owners = await contract.call("getAllOwners", [tokenId.toNumber()]);
            if (!owners) return;
            owners = owners.filter(function (owner) {
                if (owner != nullAddress) return owner;
            });

            let ownersNftInfo = [];
            await Promise.all(owners.map(async (owner) => {
                const userNFTInfo = await contract.call("publicBalances", [owner, tokenId.toNumber()]);
                ownersNftInfo.push(userNFTInfo);
            }));
            setOwners(ownersNftInfo);
        })();
    }, [])

    return (
        <>
            <Button bg={"main.100"} color={"white"} onClick={onOpen}>Collectors</Button>

            <Modal isOpen={isOpen} onClose={onClose} isCentered>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader>Collectors</ModalHeader>
                    <ModalCloseButton />
                    <ModalBody>
                        <TableContainer h={"40vh"} overflowY={"scroll"}>
                            <Table variant="simple">
                                <Thead>
                                    <Tr>
                                        <Th>Collector</Th>
                                        <Th>Address</Th>
                                        <Th>Edition</Th>
                                    </Tr>
                                </Thead>
                                <Tbody>
                                    {owners.map((owner, index) => {
                                        return (
                                            <Tr key={index}>
                                                <Td>
                                                    <Tooltip label={mask(owner.owner)} key={index}>
                                                        <Circle
                                                            size="32px"
                                                            bg="gray.200"
                                                            mr={2}
                                                            cursor="pointer"
                                                            onClick={() => router.push(`/users/${owner}`)}
                                                        >
                                                            <Image
                                                                boxSize="32px"
                                                                objectFit="cover"
                                                                src={`https://robohash.org/${owner}?set=set4`}
                                                                alt=""
                                                            />
                                                        </Circle>
                                                    </Tooltip>
                                                </Td>
                                                <Td>{mask(owner.owner)}</Td>
                                                <Td>#{owner.edition.toNumber()}</Td>
                                            </Tr>
                                        )
                                    })}
                                </Tbody>
                            </Table>
                        </TableContainer>
                    </ModalBody>

                    <ModalFooter>
                    </ModalFooter>
                </ModalContent>
            </Modal>
        </>
    )
}