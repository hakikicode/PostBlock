import {
    Flex,
    Image,
    Badge,
    useColorModeValue,
    Circle,
    Tooltip,
    Box,
    Text,
    Heading,
    Stat,
    StatLabel,
    StatNumber,
    StatHelpText,
    HStack,

} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import { nullAddress } from "../../utils/constants";
import { useSDK, useStorage } from "@thirdweb-dev/react";
import { mask } from "../../utils/mask";
import { useRouter } from "next/router";

export default function NFTAveragePriceStat({ tokenId }) {
    const sdk = useSDK();
    const storage = useStorage();
    const router = useRouter();

    const [ownersNFTInfo, setOwnersNftInfo] = useState([]);
    const [average, setAverage] = useState(0);

    useEffect(() => {
        (async () => {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            let owners = await contract.call("getAllOwners", [tokenId]);
            if (!owners) return;
            owners = owners.filter(function (owner) {
                if (owner != nullAddress) return owner;
            });

            let ownersNftInfo = [];
            await Promise.all(owners.map(async (owner) => {
                const userNFTInfo = await contract.call("publicBalances", [owner, tokenId]);
                if (userNFTInfo && !userNFTInfo.isListed) return;

                ownersNftInfo.push(userNFTInfo);
            }));
            setOwnersNftInfo(ownersNftInfo);

            if (ownersNftInfo.length === 0) return;
            console.log(ownersNftInfo);
            const average = ownersNftInfo.reduce((total, next) => total + next.price.toNumber(), 0) / ownersNftInfo.length;
            console.log(average);
            setAverage(average);
        })();
    }, []);


    return (
        <Stat>
            <StatLabel>Available Listing</StatLabel>
            <StatNumber>{ownersNFTInfo.length}</StatNumber>
            <StatHelpText>
                <HStack>
                    <Text>Average listing Price {average.toFixed(2)}</Text>
                    <Image boxSize="16px"
                        src="https://s3.us-east-2.amazonaws.com/assets.thetatoken.org/tokens/tfuel.png" alt="" />
                </HStack>
            </StatHelpText>
        </Stat>
    )
}