import {
    Popover,
    PopoverTrigger,
    PopoverContent,
    PopoverHeader,
    PopoverBody,
    PopoverFooter,
    PopoverArrow,
    PopoverCloseButton,
    Button,
    ButtonGroup,
    Box,
    Text,
    Heading,
    Stat,
    StatLabel,
    StatNumber,
    StatHelpText,
    List,
    ListItem,
    ListIcon,
    OrderedList,
    UnorderedList,
    useToast,
    Link,
} from "@chakra-ui/react";
import { useState, useEffect, useRef } from "react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { mask } from "../../utils/mask";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import { useSDK, useAddress } from "@thirdweb-dev/react";
import NFT from "./NFT";
import { ethers } from "ethers";
import NFTListing from "./NFTListing";
import NFTSupplyStat from "./NFTSupplyStat";
// import { PostBlockService } from "../../utils/PostBlockService";

export default function NFTCollect({ cid }) {
    const initialFocusRef = useRef()
    const sdk = useSDK();
    const address = useAddress();

    const [owners, setOwners] = useState([]);
    const [tokenId, setTokenId] = useState(0);
    const [isOwner, setIsOwner] = useState(false);
    const [supply, setSupply] = useState(0);

    useEffect(() => {
        (async () => {
            if (!cid) return;
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            const tokenId = await contract.call("postNFTLookup", [cid]);
            if (tokenId.toNumber() == 0) return;
            setTokenId(tokenId.toNumber());
            
            const nftInfo = await contract.call("nftInfo", [tokenId.toNumber()]);
            if (!nftInfo) return;
            setSupply(nftInfo.supply.toNumber());

            const owners = await contract.call("getAllOwners", [tokenId.toNumber()]);
            if (!owners) return;
            setOwners(owners);

            if (!address) return;
            const quantity = await contract.call("balanceOf", [address, tokenId.toNumber()]);
            const isOwner = quantity.toNumber() >= 1;
            setIsOwner(isOwner);
        })();
    }, []);

    return (
        <Popover
            initialFocusRef={initialFocusRef}
            placement="top"
            closeOnBlur={false}
        >
            <PopoverTrigger>
                <Button>Quick Buy NFT</Button>
            </PopoverTrigger>
            {tokenId != 0
                ? <PopoverContent>
                    <PopoverHeader pt={4} fontWeight="bold" border="0">
                        Collect NFT
                    </PopoverHeader>
                    <PopoverArrow />
                    <PopoverCloseButton />
                    <PopoverBody>
                        <Link href={`/nft/${tokenId}`} isExternal={"true"}>
                            <NFT tokenId={tokenId} />
                        </Link>

                        <NFTSupplyStat tokenId={tokenId} />

                        {!isOwner
                            ?
                            <>
                                <Heading size="sm">Listings</Heading>
                                <NFTListing tokenId={tokenId} />

                                {/* <List>
                                    {owners.map((owner, index) => {
                                        return (
                                            <ListItem key={index}>{<SellTab owner={owner} tokenId={tokenId} />}</ListItem>
                                        )
                                    })}
                                </List> */}
                            </>
                            : <Box>
                                <Heading size="sm">You own this NFT!</Heading>
                            </Box>
                        }
                    </PopoverBody>
                    <PopoverFooter
                        border="0"
                        display="flex"
                        alignItems="center"
                        justifyContent="space-between"
                        pb={4}
                    >
                    </PopoverFooter>
                </PopoverContent>
                : <PopoverContent>
                    <PopoverHeader pt={4} fontWeight="bold" border="0">
                        NFT Not Available
                    </PopoverHeader>
                    <PopoverArrow />
                    <PopoverCloseButton />
                </PopoverContent>}
        </Popover>
    )
}

function SellTab({ tokenId, owner }) {
    const sdk = useSDK();
    const address = useAddress();
    const toast = useToast();

    const [isListed, setIsListed] = useState(false);
    const [userNFTInfo, setUserNFTInfo] = useState({});

    useEffect(() => {
        (async () => {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);
            const userNFTInfo = await contract.call("publicBalances", [owner, tokenId]);

            if (userNFTInfo && !userNFTInfo.isListed) return;

            setIsListed(userNFTInfo.isListed);
            setUserNFTInfo(userNFTInfo);
        })();
    }, []);

    const collect = async () => {
        const contract = await sdk.getContractFromAbi(contractAddress, abi);

        const priceStr = userNFTInfo.price.toNumber().toString();
        const txOptions = { value: ethers.utils.parseEther(priceStr), };

        let toastTitle = "NFT Collected";
        let toastStatus = "success";

        try {
            const tx = await contract.call("collect", [owner, address, tokenId], txOptions);
            console.log(tx);
        } catch (e) {
            console.log(e);
            toastTitle = "NFT Not Collected";
            toastStatus = "error";
        }

        toast({ title: toastTitle, status: toastStatus, position: "bottom-right", isClosable: true });
    }

    return (
        <>
            {isListed
                ? <Box>
                    {mask(owner)} {userNFTInfo && userNFTInfo.price.toNumber()}
                    <ButtonGroup size="sm">
                        {address
                            ? <Button colorScheme="twitter" onClick={() => collect()}>Collect</Button>
                            : <Button colorScheme="twitter">Connect</Button>
                        }
                    </ButtonGroup>
                </Box>
                : <></>
            }
        </>
    )
}