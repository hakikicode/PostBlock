import {
    Flex,
    Image,
    Button,
    useColorModeValue,
    Circle,
    Tooltip,
    Box,
    Text,
    Table,
    Thead,
    Tbody,
    Tfoot,
    Tr,
    Th,
    Td,
    TableCaption,
    TableContainer,
    HStack,

} from "@chakra-ui/react";
import { useState, useEffect, useRef } from "react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import { nullAddress } from "../../utils/constants";
import { useSDK, useStorage, useAddress } from "@thirdweb-dev/react";
import { mask } from "../../utils/mask";
import { useRouter } from "next/router";
import { formatDateTime } from "../../utils/datepipe";
import { ethers } from "ethers";
import Notification from "../Notification";

export default function NFTListing({ tokenId }) {
    const sdk = useSDK();
    const storage = useStorage();
    const router = useRouter();
    const address = useAddress();
    const notificationRef = useRef();

    const [owners, setOwners] = useState([]);
    const [isOwner, setIsOwner] = useState(false);
    const [ownersNftInfo, setOwnersNftInfo] = useState([]);

    const [quantity, setQuantity] = useState(0);
    const [tfuelPrice, setTfuelPrice] = useState(null);

    useEffect(() => {
        (async () => {
            if (window && window.ethereum) {
                window.ethereum.on("accountsChanged", async (accounts) => {
                    await init();
                })
            }
            await init();
        })();
    }, [address]);

    const init = async () => {
        const contract = await sdk.getContractFromAbi(contractAddress, abi);
        let owners = await contract.call("getAllOwners", [tokenId]);
        if (!owners) return;
        owners = owners.filter(function (owner) {
            if (owner != nullAddress) return owner;
        });
        setOwners(owners);

        const id = "theta-fuel";
        const response = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${id}&vs_currencies=usd,aud`, {
            method: "GET",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json" },
        });
        const price = await response.json();
        setTfuelPrice(price[id]);

        let ownersNftInfo = [];
        await Promise.all(owners.map(async (owner) => {
            const userNFTInfo = await contract.call("publicBalances", [owner, tokenId]);
            if (userNFTInfo && !userNFTInfo.isListed) return;

            ownersNftInfo.push(userNFTInfo);
        }));
        setOwnersNftInfo(ownersNftInfo);

        if (!address) return;
        const quantity = await contract.call("balanceOf", [address, tokenId]);
        setIsOwner(quantity.toNumber() >= 1);
    }

    const collect = async (owner) => {
        if (!owner || !address) return;

        notificationRef.current.onOpen("loading", "Collecting ...", "Please wait ...");

        const contract = await sdk.getContractFromAbi(contractAddress, abi);

        // Get the price on blockchain. Again for more precise
        const userNFTInfo = await contract.call("publicBalances", [owner, tokenId]);
        if (!userNFTInfo) return;
        if (userNFTInfo && !userNFTInfo.isListed) return;

        const priceStr = userNFTInfo.price.toNumber().toString();
        const txOptions = { value: ethers.utils.parseEther(priceStr) };

        let notificationStatus = "success";
        let notificationTitle = "Collected";
        let notificationMessage = "NFT collected!";

        try {
            const tx = await contract.call("collect", [owner, address, tokenId], txOptions);
        } catch (e) {
            notificationStatus = "error";
            notificationTitle = "Error";
            notificationMessage = "Something went wrong!";
        }

        notificationRef.current.onOpen(notificationStatus, notificationTitle, notificationMessage);
        router.reload();
    }

    const renderButton = () => {
        if (address === null || address === undefined) return true;
        if (isOwner) return true;

        return false;
    }
    return (
        <Flex w="full">
            <TableContainer>
                <Table variant="simple">
                    <TableCaption>Last Updated: {new Date().toLocaleString()}</TableCaption>
                    <Thead>
                        <Tr>
                            <Th>Edition</Th>
                            <Th>Collectors</Th>
                            <Th>Price</Th>
                            <Th>Offer</Th>
                            <Th></Th>
                        </Tr>
                    </Thead>
                    <Tbody>
                        {ownersNftInfo.map((nftInfo, index) => {
                            return (
                                <Tr key={index}>
                                    <Td>
                                        <Text fontWeight={"bold"}>{nftInfo.balance > 1 ? "" : `#${nftInfo.edition.toNumber()}`}</Text>
                                    </Td>
                                    <Td>
                                        <Tooltip label={mask(nftInfo.owner)} key={index}>
                                            <Circle
                                                size="36px"
                                                bg="gray.200"
                                                mr={2}
                                                cursor="pointer"
                                                onClick={() => router.push(`/users/${nftInfo.owner}`)}
                                            >
                                                <Image
                                                    boxSize="36px"
                                                    objectFit="cover"
                                                    src={`https://robohash.org/${nftInfo.owner}?set=set4`}
                                                    alt=""
                                                />
                                            </Circle>
                                        </Tooltip>
                                    </Td>
                                    <Td>
                                        <Text>${(nftInfo.price.toNumber() * tfuelPrice["usd"]).toFixed(2)}</Text>
                                    </Td>
                                    <Td>
                                        <HStack>
                                            <Text>{nftInfo.price.toNumber()}</Text>
                                            <Image boxSize="16px"
                                                src="https://s3.us-east-2.amazonaws.com/assets.thetatoken.org/tokens/tfuel.png" alt="" />
                                        </HStack>
                                    </Td>
                                    <Td>
                                        <Button
                                            size={"sm"}
                                            isDisabled={renderButton()}
                                            onClick={() => collect(nftInfo.owner)}
                                            colorScheme="twitter">
                                            Collect
                                        </Button>
                                    </Td>
                                </Tr>
                            )
                        })}
                    </Tbody>
                    <Tfoot>
                    </Tfoot>
                </Table>
            </TableContainer>

            <Notification ref={notificationRef} />
        </Flex>
    )
}