import {
    Flex,
    Image,
    Badge,
    useColorModeValue,
    Circle,
    Tooltip,
    Box,
    Text,
    Heading,
    Stat,
    StatLabel,
    StatNumber,
    StatHelpText,

} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import { nullAddress } from "../../utils/constants";
import { useSDK, useStorage } from "@thirdweb-dev/react";
import { mask } from "../../utils/mask";
import { useRouter } from "next/router";

export default function NFTSupplyStat({ tokenId }) {
    const sdk = useSDK();
    const storage = useStorage();
    const router = useRouter();

    const [supply, setSupply] = useState(0);
    const [owners, setOwners] = useState([]);

    useEffect(() => {
        (async () => {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            const nftInfo = await contract.call("nftInfo", [tokenId]);
            if (nftInfo && nftInfo.supply) setSupply(nftInfo.supply.toNumber());

            let owners = await contract.call("getAllOwners", [tokenId]);
            if (!owners) return;
            owners = owners.filter(function (owner) {
                if (owner != nullAddress) return owner;
            });
            setOwners(owners);
        })();
    }, []);


    return (
        <Stat>
            <StatLabel>Minted</StatLabel>
            <StatNumber>{owners.length}/{supply}</StatNumber>
            <StatHelpText>{(((supply - owners.length)/supply)*100).toFixed(2)}% available</StatHelpText>
        </Stat>
    )
}