import {
    Flex,
    Image,
    Badge,
    useColorModeValue,
    Circle,
    Tooltip,
    Box,
    Text,
    Heading,
    Stat,
    StatLabel,
    StatNumber,
    StatHelpText,

} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import { nullAddress } from "../../utils/constants";
import { useSDK, useStorage } from "@thirdweb-dev/react";
import { mask } from "../../utils/mask";
import { useRouter } from "next/router";

export default function NFTOwner({ tokenId }) {
    const sdk = useSDK();
    const storage = useStorage();
    const router = useRouter();

    const [owners, setOwners] = useState([]);

    useEffect(() => {
        (async () => {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);
            
            let owners = await contract.call("getAllOwners", [tokenId]);
            console.log(owners);
            if (!owners) return;
            owners = owners.filter(function (owner) {
                if (owner != nullAddress) return owner;
            });
            setOwners(owners);
        })();
    }, []);


    return (
        <Flex p={50} w="full" alignItems="center" justifyContent="center">
            {owners.map((owner, index) => {
                return (
                    <Tooltip label={mask(owner)} key={index}>
                        <Circle
                            size="50px"
                            bg="gray.200"
                            mr={2}
                            cursor="pointer"
                            onClick={() => router.push(`/users/${owner}`)}
                        >
                            <Image
                                boxSize="50px"
                                objectFit="cover"
                                src={`https://robohash.org/${owner}?set=set4`}
                                alt=""
                            />
                        </Circle>
                    </Tooltip>
                )
            })}
        </Flex>
    )
}