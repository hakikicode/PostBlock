import {
    Button,
    Stack,
    ListItem,
    Avatar,
    Text,
    Tooltip,
    Flex,
    Box,
    Spacer,
    Accordion,
    AccordionItem,
    AccordionButton,
    AccordionPanel,
    AccordionIcon,
    Heading,
    useClipboard,
} from "@chakra-ui/react";
import { useState, useEffect, useRef } from "react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import { nullAddress } from "../../utils/constants";
import { useSDK, useStorage, useAddress } from "@thirdweb-dev/react";
import { mask } from "../../utils/mask";
import { useRouter } from "next/router";
import { formatDateTime } from "../../utils/datepipe";
import NFTList from "./NFTList";
import Notification from "../Notification";

export default function NFTDetails({ tokenId }) {
    const sdk = useSDK();
    const router = useRouter();
    const address = useAddress();
    const { onCopy, value, setValue, hasCopied } = useClipboard("");

    const [nftInfo, setNFTInfo] = useState({
        metadata: "", owner: "", isListed: false
    });
    const [details, setDetails] = useState({
        type: "PBC20",
        address: contractAddress,
        network: "Theta-Tesnet",
        tokenID: tokenId,
    });

    useEffect(() => {
        (async () => {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);
            const nftInfo = await contract.call("nftInfo", [tokenId]);
            setNFTInfo(nftInfo);
            setValue(nftInfo.owner);

            if (!address) return;
        })();
    }, [address]);

    return (
        <>
            <Stack my={6} direction={"row"} spacing={4} align={"center"}>
                <Avatar
                    src={`https://robohash.org/${nftInfo.owner}?set=set4`}
                    alt={"Author"}
                />
                <Stack direction={"column"} spacing={0} fontSize={"sm"}>
                    <Text fontWeight={700}>Creator</Text>
                    <Tooltip label={nftInfo.owner} fontSize="md">
                        <Text onClick={onCopy}>{hasCopied ? "Copied!" : mask(nftInfo.owner)}</Text>
                    </Tooltip>
                    <Button colorScheme="blue" size="sm" variant="outline"
                        onClick={() => router.push(`/posts/${nftInfo.metadata}`)}
                    >
                        Read Post
                    </Button>
                </Stack>
            </Stack>


            <Accordion allowToggle>
                <AccordionItem isexpanded>
                    <h2>
                        <AccordionButton>
                            <Box as="span" flex="1" textAlign="left" fontWeight={600}>
                                Details
                            </Box>
                            <AccordionIcon />
                        </AccordionButton>
                    </h2>
                    <AccordionPanel pb={4}>
                        {Object.keys(details).map((key, index) => {
                            return (
                                <Flex key={index} py={3} mx={3}>
                                    <Box fontWeight={"bold"} textTransform={"capitalize"}>
                                        {key}
                                    </Box>
                                    <Spacer />
                                    <Box>
                                        {key === "address" ? mask(details[key]) : details[key]}
                                    </Box>
                                </Flex>
                            )
                        })}
                    </AccordionPanel>
                </AccordionItem>
            </Accordion>
        </>
    )
}