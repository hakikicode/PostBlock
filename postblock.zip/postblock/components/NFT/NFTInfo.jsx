import {
    Button,
    Stack,
    ListItem,
    Avatar,
    Text,
    Tooltip,
    Flex,
    Box,
    Spacer,
    Accordion,
    AccordionItem,
    AccordionButton,
    AccordionPanel,
    AccordionIcon,
    Heading,
    HStack,
    StatGroup,
    useClipboard,
} from "@chakra-ui/react";
import { useState, useEffect, useRef } from "react";
import { abi } from "../../utils/PostBlockPBC20/abi";
import { contractAddress } from "../../utils/PostBlockPBC20/contract";
import { nullAddress } from "../../utils/constants";
import { useSDK, useStorage, useAddress } from "@thirdweb-dev/react";
import { mask } from "../../utils/mask";
import { useRouter } from "next/router";
import { formatDateTime } from "../../utils/datepipe";
import NFTList from "./NFTList";
import Notification from "../Notification";
import NFTSupplyStat from "./NFTSupplyStat";
import NFTAveragePriceStat from "./NFTAveragePriceStat";

export default function NFTInfo({ tokenId }) {
    const sdk = useSDK();
    const storage = useStorage();
    const router = useRouter();
    const address = useAddress();
    const notificationRef = useRef();

    const [owners, setOwners] = useState([]);
    const [isOwner, setIsOwner] = useState(false);
    const [nftInfo, setNFTInfo] = useState({
        metadata: "", owner: "", isListed: false
    });
    const [nftOwner, setNFTOwner] = useState(null);
    const [supply, setSupply] = useState(0);
    const [details, setDetails] = useState({
        type: "PBC20",
        address: contractAddress,
        network: "Theta-Tesnet",
        tokenID: tokenId,
    });

    useEffect(() => {
        (async () => {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);
            const nftInfo = await contract.call("nftInfo", [tokenId]);
            setNFTInfo(nftInfo);
            if (nftInfo && nftInfo.supply) setSupply(nftInfo.supply.toNumber());

            if (!address) return;

            const nftOwner = await contract.call("publicBalances", [address, tokenId]);
            if (!nftOwner) return;
            setNFTOwner(nftOwner);
        })();
    }, [address]);

    const unlist = async () => {
        if (!address) return;
        notificationRef.current.onOpen("loading", "Unlisting NFT", "Please wait ...");

        try {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            // List NFT
            const tx = await contract.call("unlist", [tokenId]);

            notificationRef.current.onOpen("success", "Successful unlisting", `NFT Unlisted`);
        }
        catch (err) {
            notificationRef.current.onOpen("error", "Error while unlisting", "Try again");
        }

        router.reload(window.location.pathname);
    }

    return (
        <>
            <StatGroup>
                <NFTSupplyStat tokenId={tokenId} />
                <NFTAveragePriceStat tokenId={tokenId} />
            </StatGroup>
            {(nftOwner && nftOwner.balance.toNumber() > 0)
                ? <HStack>
                    <Box>You Have Edition #{nftOwner.edition.toNumber()}</Box>
                    <NFTList tokenId={tokenId} />
                    {nftOwner.isListed
                        ? <Button onClick={() => unlist()}>Unlist</Button>
                        : <></>}
                </HStack>
                : <></>
            }

            <Notification ref={notificationRef} />
        </>
    )
}