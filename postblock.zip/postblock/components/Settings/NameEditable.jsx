import {
    Tooltip,
    InputGroup,
    Input,
    InputRightElement,
    Text,
    Heading,
    Button,
    ButtonGroup,
    IconButton,
    Editable,
    EditableInput,
    EditableTextarea,
    EditablePreview,
    useColorModeValue,
    useEditableControls,
    useToast,
} from "@chakra-ui/react";
import { CheckIcon, CloseIcon } from "@chakra-ui/icons";
import { useSDK, useAddress } from "@thirdweb-dev/react";
import { abi } from "../../utils/PostBlock/abi";
import { contractAddress } from "../../utils/PostBlock/contract";
import { useEffect, useState } from "react";

export default function NameEditable({ defaultValue }) {
    const sdk = useSDK();
    const address = useAddress();
    const toast = useToast();
    const [newUserName, setNewUserName] = useState("");
    const [opts, setOpts] = useState({});

    const saveUserName = async () => {
        if (newUserName === defaultValue) return;

        const contract = await sdk.getContractFromAbi(contractAddress, abi);

        let toastTitle = "Username updated!"
        let toastStatus = "success";

        try {
            const tx = await contract.call("setUserName", [newUserName]);
            const receipt = tx.receipt;
        }
        catch (e) {
            console.log(e);
            toastTitle = "Error updating username";
            toastStatus = "error";
        }

        toast({ title: toastTitle, status: toastStatus, position: "bottom-right", isClosable: true });
    }

    function EditableControls() {
        const {
            isEditing,
            getSubmitButtonProps,
            getCancelButtonProps,
            getEditButtonProps
        } = useEditableControls();

        return isEditing ? (
            <ButtonGroup justifyContent="end" size="sm" w="full" spacing={2} mt={2}>
                <IconButton icon={<CheckIcon />} {...getSubmitButtonProps()} />
                <IconButton icon={<CloseIcon boxSize={3} />} {...getCancelButtonProps()} />
            </ButtonGroup>
        ) : null;
    }


    useEffect(() => {
        (async () => {
            setNewUserName(defaultValue);
            const contract = await sdk.getContractFromAbi(contractAddress, abi);
            
            const userID = await contract.call("users", [address]);
            if (userID.toNumber() === 0) return;

            let user = null;
            try {
                user = await contract.call("getUserByAddress", [address]);
            } catch (error) {
                
            }
            if (user === null) return;

            const opts = {};
            if(user.name)
                opts.value = user.name;
            else
                opts.placeholder = "Add a username...";
            setOpts(opts);
        })();
    }, [address]);

    return (
        <Editable
            {...opts}
            isPreviewFocusable={true} selectAllOnFocus={false}
            fontWeight={"bold"} w={"full"}
            fontSize={"2xl"} fontFamily={"body"}
            value={newUserName}
            onChange={(e) => setNewUserName(e)}
            onSubmit={() => saveUserName()}
        >
            <Tooltip label="Click to edit" shouldWrapChildren={true}>
                <EditablePreview
                    py={2} px={4}
                    _hover={{ background: useColorModeValue("gray.100", "gray.700") }}
                />
            </Tooltip>
            <Input py={2} px={4} as={EditableInput} />
            <EditableControls />
        </Editable>
    );
}