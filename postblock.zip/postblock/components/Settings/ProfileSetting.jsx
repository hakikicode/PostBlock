import {
    Heading,
    Avatar,
    Box,
    Center,
    Text,
    Stack,
    Button,
    Link,
    Badge,
    Editable,
    EditableInput,
    EditableTextarea,
    EditablePreview,
    useColorModeValue,
} from "@chakra-ui/react";
import { ExternalLinkIcon, PlusSquareIcon } from "@chakra-ui/icons";
import { EMPTYUSER } from "../../utils/constants";
import { abi } from "../../utils/PostBlock/abi";
import { contractAddress } from "../../utils/PostBlock/contract";
import { useAddress, useSDK } from "@thirdweb-dev/react";
import { useEffect, useState } from "react";
import NameEditable from "./NameEditable";
import DescriptionEditable from "./DescriptionEditable";
import { useRouter } from "next/router";
import NewUser from "../NewUser";

export default function ProfileSetting({ }) {
    const sdk = useSDK();
    const address = useAddress();
    const router = useRouter();
    const profileBackground = useColorModeValue("white", "gray.900");

    const [totalPosts, setTotalPosts] = useState(0);
    const [totalFollowers, setTotalFollowers] = useState(0);
    const [isUser, setIsUser] = useState(false);
    const [user, setUser] = useState(null);

    useEffect(() => {
        (async () => {
            await init();
        })();
    }, [address]);

    const init = async () => {
        setIsUser(false);
        setUser(null);

        const contract = await sdk.getContractFromAbi(contractAddress, abi);
        if (!address) return;

        const userID = await contract.call("users", [address]);
        if (userID.toNumber() === 0) return;

        let user = null;
        try {
            user = await contract.call("getUserByAddress", [address]);
        } catch (error) {
            return;
        }
        if (!user) return;

        setIsUser(true);
        setUser(user);
        const totalPosts = await contract.call("getUserPosts", [address]);
        const totalFollowers = await contract.call("totalMembers", [address]);

        setTotalPosts(totalPosts.toNumber());
        setTotalFollowers(totalFollowers.toNumber());
    }
    return (
        <>

            <Center py={6}>
                <Box maxW={"320px"} w={"full"}
                    bg={profileBackground}
                    boxShadow={"2xl"} rounded={"lg"} p={6} textAlign={"center"}
                >
                    <Avatar size={"xl"} alt={"Avatar Alt"} mb={4} pos={"relative"}
                        src={`https://robohash.org/${address ? address : contractAddress}?set=set4`}
                    />

                    {(isUser && address)
                        ? <>
                            <NameEditable defaultValue={user.name || ""} />
                            <DescriptionEditable defaultValue={user.description || ""} />

                            <Stack direction={"row"} justify={"center"} spacing={6} mt={6}>
                                <Stack spacing={0} align={"center"}>
                                    <Text fontWeight={600}>{totalPosts}</Text>
                                    <Text fontSize={"sm"} color={"gray.500"}>Posts</Text>
                                </Stack>
                                <Stack spacing={0} align={"center"}>
                                    <Text fontWeight={600}>{totalFollowers}</Text>
                                    <Text fontSize={"sm"} color={"gray.500"}>Followers</Text>
                                </Stack>
                            </Stack>
                        </>
                        : <NewUser />}
                    <Button flex="1" variant="ghost" leftIcon={<ExternalLinkIcon />}
                        onClick={() => router.push({ pathname: '/users/[address]', query: { address: address } })}
                    >
                        View Profile
                    </Button>
                </Box>
            </Center >
        </>
    );
}