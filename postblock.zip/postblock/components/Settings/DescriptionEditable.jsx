import {
    Tooltip,
    InputGroup,
    Input,
    InputRightElement,
    Text,
    Heading,
    Button,
    ButtonGroup,
    IconButton,
    Editable,
    EditableInput,
    EditableTextarea,
    EditablePreview,
    useColorModeValue,
    useEditableControls,
    useToast,
} from "@chakra-ui/react";
import { CheckIcon, CloseIcon } from "@chakra-ui/icons";
import { useSDK, useAddress } from "@thirdweb-dev/react";
import { abi } from "../../utils/PostBlock/abi";
import { contractAddress } from "../../utils/PostBlock/contract";
import { useEffect, useState } from "react";

export default function DescriptionEditable({ defaultValue }) {
    const sdk = useSDK();
    const address = useAddress();
    const toast = useToast();
    const [newDescription, setNewDescription] = useState("");
    const [opts, setOpts] = useState({});

    const saveDescription = async () => {
        if (newDescription === defaultValue) return;

        const contract = await sdk.getContractFromAbi(contractAddress, abi);

        let toastTitle = "Description updated!"
        let toastStatus = "success";

        try {
            const tx = await contract.call("setUserDescription", [newDescription]);
            const receipt = tx.receipt;
        }
        catch (e) {
            toastTitle = "Error updating description";
            toastStatus = "error";
        }

        toast({ title: toastTitle, status: toastStatus, position: "bottom-right", isClosable: true });
    }

    /* Here"s a custom control */
    function EditableControls() {
        const {
            isEditing,
            getSubmitButtonProps,
            getCancelButtonProps,
            getEditButtonProps
        } = useEditableControls();

        return isEditing ? (
            <ButtonGroup justifyContent="end" size="sm" w="full" spacing={2} mt={2}>
                <IconButton icon={<CheckIcon />} {...getSubmitButtonProps()} />
                <IconButton
                    icon={<CloseIcon boxSize={3} />}
                    {...getCancelButtonProps()}
                />
            </ButtonGroup>
        ) : null;
    }

    useEffect(() => {
        (async () => {
            setNewDescription(defaultValue);
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            const userID = await contract.call("users", [address]);
            if (userID.toNumber() === 0) return;

            let user = null;
            try {
                user = await contract.call("getUserByAddress", [address]);
            } catch (error) {
                console.log(e);
            }
            if (user === null) return;

            const opts = {};
            if (user.description)
                opts.value = user.description;
            else
                opts.placeholder = "Add a description...";
            setOpts(opts);
        })();
    }, []);

    return (
        <Editable
            {...opts}
            isPreviewFocusable={true} selectAllOnFocus={false}
            as={Text} px={3} textAlign={"center"}
            color={useColorModeValue("gray.700", "gray.400")}
            onChange={(e) => setNewDescription(e)}
            onSubmit={() => saveDescription()}
        >
            <Tooltip label="Click to edit" shouldWrapChildren={true}>
                <EditablePreview
                    py={2}
                    px={4}
                    _hover={{
                        background: useColorModeValue("gray.100", "gray.700")
                    }}
                />
            </Tooltip>
            <Input py={2} px={4} as={EditableInput} />
            <EditableControls />
        </Editable>
    );
}