import {
    Container,
    Grid,
    GridItem,
    Flex,
    Box,
    Text,
    Heading,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useSDK } from "@thirdweb-dev/react";
import { abi } from "../../utils/PostBlock/abi";
import { contractAddress } from "../../utils/PostBlock/contract";
import { abi as PBC20abi } from "../../utils/PostBlockPBC20/abi"
import { contractAddress as PBC20ContractAddress } from "../../utils/PostBlockPBC20/contract"

export default function Statistic() {
    const sdk = useSDK();

    const [totalPosts, setTotalPosts] = useState(0);
    const [totalUsers, setTotalUsers] = useState(0);
    const [totalNFTMinted, setTotalNFTMinted] = useState(0);

    useEffect(() => {
        (async () => {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            const totalPostsBigNumber = await contract.call("getTotalPosts");
            const totalUsersBigNumber = await contract.call("getTotalUsers");
            setTotalPosts(totalPostsBigNumber.toNumber());
            setTotalUsers(totalUsersBigNumber.toNumber());

            const PBC20Contract = await sdk.getContractFromAbi(PBC20ContractAddress, PBC20abi);
            const totalNFTs = await PBC20Contract.call("idCounter");
            console.log(totalNFTs);

            if (!totalNFTs) return;
            const ids = Array(totalNFTs.toNumber()).fill(1).map((x, y) => x + y);
            console.log(ids);

            let totalNFTMinted = 0;
            await Promise.all(ids.map(async (tokenId) => {
                const totalOwners = await PBC20Contract.call("totalOwners", [tokenId]);
                totalNFTMinted += totalOwners.toNumber();
            }));
            setTotalNFTMinted(totalNFTMinted);
        })();
    }, []);

    return (
        <Container py={5} maxW={"container.lg"}>
            <Grid templateColumns="repeat(12, 1fr)" gap={6}>
                <GridItem colSpan={6}>
                    <Heading as={"h2"}>Statistics</Heading>
                </GridItem>
                <GridItem colSpan={2}>
                    <Flex flexDirection={"column"}>
                        <Text fontSize={"4xl"} fontWeight={"bold"}>
                            {totalPosts}
                        </Text>
                        <Text color={"gray.600"} fontSize={{ base: "sm", sm: "lg" }}>
                            Total Posts
                        </Text>
                    </Flex>
                </GridItem>
                <GridItem colSpan={2}>
                    <Flex flexDirection={"column"}>
                    <Text fontSize={"4xl"} fontWeight={"bold"}>
                            {totalUsers}
                        </Text>
                        <Text color={"gray.600"} fontSize={{ base: "sm", sm: "lg" }}>
                            Total Users
                        </Text>
                    </Flex>
                </GridItem>
                <GridItem colSpan={2}>
                    <Flex flexDirection={"column"}>
                    <Text fontSize={"4xl"} fontWeight={"bold"}>
                            {totalNFTMinted}
                        </Text>
                        <Text color={"gray.600"} fontSize={{ base: "sm", sm: "lg" }}>
                            Total NFT Minted
                        </Text>
                    </Flex>
                </GridItem>
            </Grid>
        </Container>
        
    );
}
