import {
    Stack,
    Container,
    Box,
    Flex,
    Text,
    Heading,
    SimpleGrid,
    Link,
    useColorModeValue,
} from "@chakra-ui/react";
import { ExternalLinkIcon } from "@chakra-ui/icons";
import { Icon } from "@iconify/react";
import { explorer } from "../../utils/constants";
import { contractAddress } from "../../utils/PostBlock/contract";
import { contractAddress as PBC20ContractAddress } from "../../utils/PostBlockPBC20/contract";

export default function Feature() {
    const iconColor = useColorModeValue("gray.700", "gray.400");

    return (
        <Box position={"relative"}>
            <Flex
                flex={1}
                zIndex={0}
                display={{ base: "none", lg: "flex" }}
                position={"absolute"}
                width={"50%"}
                insetY={0}
                right={0}>
            </Flex>
            <Container maxW={"7xl"} zIndex={10} position={"relative"}>
                <Stack direction={{ base: "column", lg: "row" }}>
                    <Stack
                        flex={1}
                        // color={"gray.400"}
                        justify={{ lg: "center" }}
                        py={{ base: 4, md: 20, xl: 60 }}>
                        <Box mb={{ base: 8, md: 20 }}>
                            <Text
                                fontFamily={"heading"}
                                fontWeight={700}
                                textTransform={"uppercase"}
                                mb={3}
                                fontSize={"xl"}
                                id={"feature"}
                            >
                                PostBlock chain Network
                            </Text>
                            <Heading
                                // color={"white"}
                                mb={5}
                                fontSize={{ base: "3xl", md: "5xl" }}>
                                CrowdFunding, Charity, Donation Posting
                            </Heading>
                            <Text fontSize={"xl"} color={"gray.400"}>
                                Post on PostBlock which uses Web3 and the Theta blockchain technologoy to enable publishers earn rewards by posting on PostBlock App about crowdfunding and other issues which enables
+                                content creators to post and publish things related donation, charity and crowdfunding recommeding or posting towards a cause on secured and decentralized ways,
                                ensuring full complete claim of their work,write-ups or articles, authenticity, and transparency while providing a risk free
                                environment.
                            </Text>
                        </Box>

                        <SimpleGrid columns={{ base: 1, md: 2 }} spacing={10}>
                            {stats.map((stat, index) => (
                                <Box key={index}>
                                    <Text
                                        fontFamily={"heading"}
                                        fontSize={"3xl"}
                                        color={iconColor}
                                        mb={3}>
                                        <Icon icon={stat.icon} />
                                    </Text>
                                    <Text fontSize={"xl"} color={"gray.400"}>
                                        {stat.content}
                                    </Text>
                                </Box>
                            ))}
                        </SimpleGrid>
                    </Stack>
                    <Flex flex={1} />
                </Stack>
            </Container>
        </Box>
    );
}

const StatsText = ({ children }) => (
    <Text as={"span"} fontWeight={700}>
        {children}
    </Text>
);

const stats = [
    {
        icon: "carbon:block-storage",
        content: (
            <>
                With <StatsText>Post StorageBlock</StatsText>, documents can be stored and accessed by blocks, reducing reliance on a
                central server and improving accessibility and speed.
            </>
        ),
    },
    {
        icon: "clarity:block-line",
        content: (
            <>
                <StatsText>Blockchain Technology</StatsText> offers a secure and decentralized approach
                to data storage, eliminating the need for a central authority to
                manage data and ensuring the accuracy and consistency of stored
                information.
            </>
        ),
    },
    {
        icon: "ri:nft-line",
        content: (
            <>
                PostBlock Chain <StatsText>PBC20</StatsText> tokens on the publishing
                platform using it as a native token for payment, reward and earning for both publisher and advertisers and readers to also enhance the distribution and management of
                various digital content types, providing a more efficient and
                flexible experience for your writers and readers and advertisers.
            </>
        ),
    },
    {
        icon: "teenyicons:contract-outline",
        content: (
            <>
                <StatsText>TestNet Smart Contract</StatsText> <br />
                <Link href={`${explorer}/address/${contractAddress}`} isExternal>PostBlock Smart Contract Address <ExternalLinkIcon /></Link> <br />
                <Link href={`${explorer}/address/${PBC20ContractAddress}`} isExternal>PostBlockNFT PBC20 Address <ExternalLinkIcon /></Link> <br />
            </>
        ),
    },
];