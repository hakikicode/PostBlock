import {
    SimpleGrid,
    Heading,
    Stack,
    Text,
    Container
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useSDK } from "@thirdweb-dev/react";
import { abi } from "../../utils/PostBlock/abi";
import { contractAddress } from "../../utils/PostBlock/contract";
import Post from "../Post";

export default function SamplePost() {
    const sdk = useSDK();

    const [totalUsers, setTotalUsers] = useState(0);
    const [cids, setCids] = useState([]);

    useEffect(() => {
        (async () => {
            const contract = await sdk.getContractFromAbi(contractAddress, abi);

            const totalUsersBigNumber = await contract.call("getTotalUsers");
            setTotalUsers(totalUsersBigNumber.toNumber());
            if (totalUsersBigNumber.toNumber() <= 0) return;

            let ids = [];
            for (let i = 0; i < 5; i++) {
                const randomUser = Math.floor(Math.random() * totalUsersBigNumber.toNumber()) + 1;
                ids.push(randomUser);
            }
            ids = [...new Set(ids)];    // Dinstinct array

            let cids = [];
            for (let id of ids) { 
                let user = null;
                try {
                    user = await contract.call("getUserByID", [id]);    // This can throw err if id doesn"t exist
                }
                catch (e) {
                    console.log(e);
                    continue;
                }

                if (!user) continue;

                try {
                    let posts = await contract.call("getPost", [user.addr]);
                    if (posts.length > 0)
                        posts.slice(0, 1).map((item) => { cids.push(item.cid); });
                }
                catch (e) {
                    console.log(e);
                    continue;
                }
            }
            if (cids.length >= 3) cids = cids.slice(0, 3);
            setCids(cids);
        })();
    }, []);
    return (
        <>
            <Stack spacing={4} as={Container} maxW={"3xl"} textAlign={"center"}>
                <Heading as={"h2"}>Check out the Latest</Heading>
            </Stack>
            <SimpleGrid minChildWidth='445px' spacing='40px'>
                {cids.map((cid, index) => {
                    return (
                        <Post key={index} cid={cid} />
                    );
                })}
            </SimpleGrid>
        </>
    );
}
