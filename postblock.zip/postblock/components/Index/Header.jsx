import {
  Box,
  Heading,
  Container,
  Text,
  Button,
  Stack,
  Link,
} from "@chakra-ui/react";
import { useRouter } from "next/router";

export default function Header() {
  const router = useRouter();
  
  return (
    <>
      <Container maxW={"3xl"}>
        <Stack
          as={Box}
          textAlign={"center"}
          spacing={{ base: 8, md: 14 }}
          py={{ base: 20, md: 36 }}>
          <Heading
            fontWeight={800}
            fontSize={{ base: "2xl", sm: "4xl", md: "6xl" }}
            lineHeight={"110%"}>
            Post <br />
            <Text as={"span"} color={"#2AB8E6"}>
              Block
            </Text>
          </Heading>
          <Text color={"gray.500"}>
            Join a decentralized crowdfunding post network on Theta Blockchain
            and Web3 technology, making content claim on charity, crowdfunding, authenticity,
            and transparency, while Post Storage Block and The Standard POSTBLOCK CHAIN PBC20 tokens
            for content reward, earning, distribution and to manage.
          </Text>
          <Stack
            direction={"column"}
            spacing={3}
            align={"center"}
            alignSelf={"center"}
            position={"relative"}>
            <Button
              colorScheme={"twitter"}
              onClick={() => router.push("/write")}
              rounded={"full"}
              px={6}
            >
              Learn More
            </Button>
            <Link variant={"link"}
              href="#feature"
              colorScheme={"twitter"} size={"sm"}>
              Get Started
            </Link>
          </Stack>
        </Stack>
      </Container>
    </>
  );
}