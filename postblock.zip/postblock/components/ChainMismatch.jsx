import { Box, Heading, Button } from "@chakra-ui/react";
import {
    useSDK,
    useAddress, 
    useSwitchChain,
    useChainId,
} from "@thirdweb-dev/react";
import { useRouter } from "next/router";
import { ThetaTestnet } from "@thirdweb-dev/chains";

export default function ChainMismatch({ }) {
    // const sdk = useSDK();
    // const address = useAddress();
    // const chainId = useChainId();
    const switchChain = useSwitchChain();
    const router = useRouter();

    const handleChainSwitch = async () => {
        await switchChain(ThetaTestnet.chainId);
        router.reload();
    }

    return (
        <Box textAlign="center" py={10} px={6}>
            <Heading as="h2" size="xl" mt={6} mb={2}>
                Incorrect Network. Please switch to Theta Testnet.
            </Heading>
            <Button colorScheme="messenger" variant="outline" onClick={() => handleChainSwitch()}>
                Switch Networks
            </Button>
        </Box>
    );
}